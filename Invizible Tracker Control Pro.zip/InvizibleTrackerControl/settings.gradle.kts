rootProject.name = "Invizible Tracker Control Pro"

include(":app")
include(":core")
include(":tracker")
include(":dnscrypt")
include(":tor")
include(":i2p")