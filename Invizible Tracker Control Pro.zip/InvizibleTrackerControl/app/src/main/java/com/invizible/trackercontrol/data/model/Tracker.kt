package com.invizible.trackercontrol.data.model

/**
 * Data model representing a tracker
 */
data class Tracker(
    val id: String,
    val domain: String,
    val company: String,
    val category: TrackerCategory,
    val description: String,
    val isBlocked: Boolean = true,
    val lastSeen: Long = 0L,
    val occurrenceCount: Int = 0,
    val associatedApps: Set<String> = emptySet()
)

/**
 * Tracker categories for classification
 */
enum class TrackerCategory {
    ADVERTISING,
    ANALYTICS,
    SOCIAL_MEDIA,
    CDN,
    MARKETING,
    CRM,
    FINGERPRINTING,
    MALWARE,
    TRACKING_PIXEL,
    EMAIL_TRACKING,
    SESSION_RECORDING,
    HEATMAP,
    A_B_TESTING,
    PERSONALIZATION,
    RECOMMENDATION,
    SEARCH_ANALYTICS,
    AFFILIATE_MARKETING,
    DATA_BROKER,
    GOVERNMENT,
    OTHER
}

/**
 * Tracker database entry
 */
data class TrackerDatabaseEntry(
    val domain: String,
    val company: String,
    val category: TrackerCategory,
    val signatures: List<String>,
    val ipRanges: List<String>,
    val lastUpdated: Long,
    val version: Int
)

/**
 * Tracker detection result
 */
data class TrackerDetectionResult(
    val isTracker: Boolean,
    val tracker: Tracker? = null,
    val confidence: Float = 0.0f,
    val detectionMethod: DetectionMethod,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Tracker detection methods
 */
enum class DetectionMethod {
    DOMAIN_MATCH,
    IP_MATCH,
    SIGNATURE_MATCH,
    BEHAVIORAL_ANALYSIS,
    DNS_ANALYSIS,
    CERTIFICATE_ANALYSIS
}

/**
 * Tracker blocking statistics
 */
data class TrackerStats(
    val totalTrackersBlocked: Long = 0L,
    val totalTrackersDetected: Long = 0L,
    val mostCommonTracker: String? = null,
    val mostCommonCategory: TrackerCategory? = null,
    val appsWithMostTrackers: List<String> = emptyList(),
    val lastTrackerBlocked: Long = 0L
)

/**
 * Tracker SDK information
 */
data class TrackerSDK(
    val name: String,
    val packageName: String,
    val version: String,
    val signatures: List<String>,
    val permissions: List<String>,
    val category: TrackerCategory,
    val description: String
)