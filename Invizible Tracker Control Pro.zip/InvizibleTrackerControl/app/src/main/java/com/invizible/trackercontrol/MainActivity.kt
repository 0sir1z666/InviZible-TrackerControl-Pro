package com.invizible.trackercontrol

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.invizible.trackercontrol.ui.theme.TrackerControlTheme
import dagger.hilt.android.AndroidEntryPoint

/**
 * Main activity for Invizible Tracker Control Pro
 * 
 * This activity serves as the entry point for the application and hosts
 * the main navigation graph for all UI screens.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    
    private lateinit var navController: NavHostController
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        setContent {
            TrackerControlTheme {
                // Create navigation controller
                navController = rememberNavController()
                
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    // Main navigation host
                    MainNavHost(navController = navController)
                }
            }
        }
    }
    
    override fun onResume() {
        super.onResume()
        // Check VPN status when activity resumes
        checkVPNStatus()
    }
    
    private fun checkVPNStatus() {
        // Check if VPN service is running
        // Update UI accordingly
    }
}