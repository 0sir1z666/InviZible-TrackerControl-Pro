package com.invizible.trackercontrol.ui.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.invizible.trackercontrol.R
import com.invizible.trackercontrol.data.model.VPNStatus
import com.invizible.trackercontrol.data.model.AppStats
import com.invizible.trackercontrol.ui.components.GlobalToggle
import com.invizible.trackercontrol.ui.navigation.Screen

/**
 * Main dashboard screen for Invizible Tracker Control Pro
 * 
 * This screen provides:
 * - VPN status and connection information
 * - Global privacy toggles (Tracker Control, DNSCrypt, Tor, I2P)
 * - Quick statistics and metrics
 * - Navigation to other screens
 */
@Composable
fun DashboardScreen(
    navController: NavController,
    viewModel: DashboardViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // App Header
        AppHeader()
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Status Cards Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            VPNStatusCard(
                status = state.vpnStatus,
                modifier = Modifier.weight(1f)
            )
            
            Spacer(modifier = Modifier.width(8.dp))
            
            QuickStatsCard(
                stats = state.stats,
                modifier = Modifier.weight(1f)
            )
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Global Toggles Section
        GlobalTogglesSection(
            trackerControlEnabled = state.trackerControlEnabled,
            dnscryptEnabled = state.dnscryptEnabled,
            torEnabled = state.torEnabled,
            i2pEnabled = state.i2pEnabled,
            onToggleChanged = viewModel::onToggleChanged
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Quick Actions Section
        QuickActionsSection(
            onAppManagementClick = {
                navController.navigate(Screen.AppManagement.route)
            },
            onSettingsClick = {
                navController.navigate(Screen.Settings.route)
            },
            onLogsClick = {
                navController.navigate(Screen.Logs.route)
            }
        )
    }
}

@Composable
private fun AppHeader() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                painter = painterResource(id = R.drawable.ic_shield),
                contentDescription = "App Icon",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(48.dp)
            )
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column {
                Text(
                    text = "Invizible Tracker Control Pro",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                
                Text(
                    text = "Complete Privacy Protection",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun VPNStatusCard(
    status: VPNStatus,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .height(120.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    painter = painterResource(
                        id = if (status.isConnected) R.drawable.ic_status_connected 
                             else R.drawable.ic_status_disconnected
                    ),
                    contentDescription = "VPN Status",
                    tint = if (status.isConnected) Color.Green else Color.Red,
                    modifier = Modifier.size(24.dp)
                )
                
                Spacer(modifier = Modifier.width(8.dp))
                
                Text(
                    text = if (status.isConnected) "Connected" else "Disconnected",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            
            Text(
                text = "IP: ${status.virtualIP}",
                style = MaterialTheme.typography.bodySmall
            )
            
            Text(
                text = "Duration: ${status.duration}",
                style = MaterialTheme.typography.bodySmall
            )
            
            if (status.isConnected) {
                Text(
                    text = "Server: ${status.serverLocation}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun QuickStatsCard(
    stats: AppStats,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .height(120.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            StatItem(
                label = "Apps Protected",
                value = "${stats.appsProtected}",
                icon = painterResource(id = R.drawable.ic_apps)
            )
            
            StatItem(
                label = "Trackers Blocked",
                value = formatNumber(stats.trackersBlocked),
                icon = painterResource(id = R.drawable.ic_block)
            )
            
            StatItem(
                label = "Data Encrypted",
                value = formatBytes(stats.dataEncrypted),
                icon = painterResource(id = R.drawable.ic_security)
            )
        }
    }
}

@Composable
private fun GlobalTogglesSection(
    trackerControlEnabled: Boolean,
    dnscryptEnabled: Boolean,
    torEnabled: Boolean,
    i2pEnabled: Boolean,
    onToggleChanged: (ToggleType, Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Global Privacy Controls",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            GlobalToggle(
                title = "Tracker Control",
                description = "Block trackers and analytics",
                enabled = trackerControlEnabled,
                onToggle = { enabled ->
                    onToggleChanged(ToggleType.TRACKER_CONTROL, enabled)
                }
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            GlobalToggle(
                title = "DNSCrypt",
                description = "Encrypt DNS queries",
                enabled = dnscryptEnabled,
                onToggle = { enabled ->
                    onToggleChanged(ToggleType.DNSCRYPT, enabled)
                }
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            GlobalToggle(
                title = "Tor Network",
                description = "Route through Tor for anonymity",
                enabled = torEnabled,
                onToggle = { enabled ->
                    onToggleChanged(ToggleType.TOR, enabled)
                }
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            GlobalToggle(
                title = "I2P Network",
                description = "Route through I2P network",
                enabled = i2pEnabled,
                onToggle = { enabled ->
                    onToggleChanged(ToggleType.I2P, enabled)
                }
            )
        }
    }
}

@Composable
private fun QuickActionsSection(
    onAppManagementClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onLogsClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Quick Actions",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                QuickActionButton(
                    title = "App Management",
                    icon = painterResource(id = R.drawable.ic_apps),
                    onClick = onAppManagementClick
                )
                
                QuickActionButton(
                    title = "Settings",
                    icon = painterResource(id = R.drawable.ic_settings),
                    onClick = onSettingsClick
                )
                
                QuickActionButton(
                    title = "View Logs",
                    icon = painterResource(id = R.drawable.ic_logs),
                    onClick = onLogsClick
                )
            }
        }
    }
}

// Helper functions
@Composable
private fun StatItem(label: String, value: String, icon: androidx.compose.ui.graphics.painter.Painter) {
    Row(
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            painter = icon,
            contentDescription = label,
            modifier = Modifier.size(16.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
        
        Spacer(modifier = Modifier.width(4.dp))
        
        Column {
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold
            )
            
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun QuickActionButton(
    title: String,
    icon: androidx.compose.ui.graphics.painter.Painter,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(8.dp)
    ) {
        Icon(
            painter = icon,
            contentDescription = title,
            modifier = Modifier.size(32.dp),
            tint = MaterialTheme.colorScheme.primary
        )
        
        Spacer(modifier = Modifier.height(4.dp))
        
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

private fun formatNumber(number: Long): String {
    return when {
        number >= 1000000 -> "${number / 1000000}M"
        number >= 1000 -> "${number / 1000}K"
        else -> number.toString()
    }
}

private fun formatBytes(bytes: Long): String {
    return when {
        bytes >= 1024 * 1024 * 1024 -> "${bytes / (1024 * 1024 * 1024)}GB"
        bytes >= 1024 * 1024 -> "${bytes / (1024 * 1024)}MB"
        bytes >= 1024 -> "${bytes / 1024}KB"
        else -> "${bytes}B"
    }
}

enum class ToggleType {
    TRACKER_CONTROL,
    DNSCRYPT,
    TOR,
    I2P
}