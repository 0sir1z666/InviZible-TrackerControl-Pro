package com.invizible.trackercontrol.ui.theme

import androidx.compose.ui.graphics.Color

// Primary colors
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Custom theme colors
val PrimaryGreen = Color(0xFF4CAF50)
val PrimaryBlue = Color(0xFF2196F3)
val PrimaryRed = Color(0xFFF44336)
val PrimaryOrange = Color(0xFFFF9800)

// Status colors
val StatusConnected = Color(0xFF4CAF50)
val StatusDisconnected = Color(0xFFF44336)
val StatusConnecting = Color(0xFFFF9800)

// Background colors
val BackgroundLight = Color(0xFFF5F5F5)
val BackgroundDark = Color(0xFF121212)

// Surface colors
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceDark = Color(0xFF1E1E1E)

// Text colors
val TextPrimaryLight = Color(0xFF000000)
val TextPrimaryDark = Color(0xFFFFFFFF)
val TextSecondaryLight = Color(0xFF666666)
val TextSecondaryDark = Color(0xFFCCCCCC)

// Privacy indicator colors
val PrivacyHigh = Color(0xFF4CAF50)
val PrivacyMedium = Color(0xFFFF9800)
val PrivacyLow = Color(0xFFF44336)

// Tracker blocking colors
val TrackerBlocked = Color(0xFF4CAF50)
val TrackerAllowed = Color(0xFFFF9800)

// Network routing colors
val RouteDirect = Color(0xFF2196F3)
val RouteTor = Color(0xFF9C27B0)
val RouteI2P = Color(0xFF795548)
val RouteBlocked = Color(0xFF607D8B)