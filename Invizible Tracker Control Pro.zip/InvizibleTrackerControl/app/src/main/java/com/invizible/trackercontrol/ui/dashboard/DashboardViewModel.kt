package com.invizible.trackercontrol.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.invizible.trackercontrol.data.model.*
import com.invizible.trackercontrol.data.repository.SettingsRepository
import com.invizible.trackercontrol.data.repository.VPNRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel for the Dashboard screen
 * 
 * Manages the state of the dashboard including:
 * - VPN connection status
 * - Privacy control toggles
 * - Statistics and metrics
 */
@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val vpnRepository: VPNRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {
    
    private val _state = MutableStateFlow(DashboardState())
    val state: StateFlow<DashboardState> = _state.asStateFlow()
    
    init {
        loadInitialState()
        observeVPNStatus()
        observeSettings()
    }
    
    private fun loadInitialState() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true)
            
            try {
                // Load VPN status
                val vpnStatus = vpnRepository.getVPNStatus()
                
                // Load statistics
                val stats = vpnRepository.getStats()
                
                // Load settings
                val settings = settingsRepository.getSettings()
                
                _state.value = _state.value.copy(
                    vpnStatus = vpnStatus,
                    stats = stats,
                    trackerControlEnabled = settings.trackerControlEnabled,
                    dnscryptEnabled = settings.dnsCryptEnabled,
                    torEnabled = settings.torEnabled,
                    i2pEnabled = settings.i2pEnabled,
                    isLoading = false
                )
                
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    error = e.message ?: "Failed to load initial state",
                    isLoading = false
                )
            }
        }
    }
    
    private fun observeVPNStatus() {
        viewModelScope.launch {
            vpnRepository.observeVPNStatus()
                .catch { e ->
                    _state.value = _state.value.copy(
                        error = e.message ?: "Error observing VPN status"
                    )
                }
                .collect { status ->
                    _state.value = _state.value.copy(vpnStatus = status)
                }
        }
    }
    
    private fun observeSettings() {
        viewModelScope.launch {
            settingsRepository.observeSettings()
                .catch { e ->
                    _state.value = _state.value.copy(
                        error = e.message ?: "Error observing settings"
                    )
                }
                .collect { settings ->
                    _state.value = _state.value.copy(
                        trackerControlEnabled = settings.trackerControlEnabled,
                        dnscryptEnabled = settings.dnsCryptEnabled,
                        torEnabled = settings.torEnabled,
                        i2pEnabled = settings.i2pEnabled
                    )
                }
        }
    }
    
    fun onToggleChanged(toggleType: ToggleType, enabled: Boolean) {
        viewModelScope.launch {
            try {
                when (toggleType) {
                    ToggleType.TRACKER_CONTROL -> {
                        settingsRepository.setTrackerControlEnabled(enabled)
                        _state.value = _state.value.copy(trackerControlEnabled = enabled)
                    }
                    
                    ToggleType.DNSCRYPT -> {
                        settingsRepository.setDNSCryptEnabled(enabled)
                        _state.value = _state.value.copy(dnscryptEnabled = enabled)
                        
                        if (enabled) {
                            vpnRepository.startDNSCrypt()
                        } else {
                            vpnRepository.stopDNSCrypt()
                        }
                    }
                    
                    ToggleType.TOR -> {
                        settingsRepository.setTorEnabled(enabled)
                        _state.value = _state.value.copy(torEnabled = enabled)
                        
                        if (enabled) {
                            vpnRepository.startTor()
                        } else {
                            vpnRepository.stopTor()
                        }
                    }
                    
                    ToggleType.I2P -> {
                        settingsRepository.setI2PEnabled(enabled)
                        _state.value = _state.value.copy(i2pEnabled = enabled)
                        
                        if (enabled) {
                            vpnRepository.startI2P()
                        } else {
                            vpnRepository.stopI2P()
                        }
                    }
                }
                
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    error = "Failed to update ${toggleType.name}: ${e.message}"
                )
            }
        }
    }
    
    fun clearError() {
        _state.value = _state.value.copy(error = null)
    }
    
    fun refreshStats() {
        viewModelScope.launch {
            try {
                val stats = vpnRepository.getStats()
                _state.value = _state.value.copy(stats = stats)
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    error = "Failed to refresh stats: ${e.message}"
                )
            }
        }
    }
}

/**
 * Dashboard UI state
 */
data class DashboardState(
    val vpnStatus: VPNStatus = VPNStatus(),
    val stats: AppStats = AppStats(),
    val trackerControlEnabled: Boolean = true,
    val dnscryptEnabled: Boolean = false,
    val torEnabled: Boolean = false,
    val i2pEnabled: Boolean = false,
    val isLoading: Boolean = false,
    val error: String? = null
)

/**
 * Toggle types for global privacy controls
 */
enum class ToggleType {
    TRACKER_CONTROL,
    DNSCRYPT,
    TOR,
    I2P
}