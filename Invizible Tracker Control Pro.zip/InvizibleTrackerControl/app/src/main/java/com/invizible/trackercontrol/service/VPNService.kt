package com.invizible.trackercontrol.service

import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.system.OsConstants
import android.util.Log
import com.invizible.core.vpn.VPNCore
import com.invizible.core.packet.PacketProcessor
import com.invizible.core.routing.RoutingEngine
import com.invizible.trackercontrol.MainActivity
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.InetAddress
import javax.inject.Inject

/**
 * Main VPN Service for Invizible Tracker Control Pro
 * 
 * This service implements the core VPN functionality that:
 * - Routes all device traffic through a single VPN tunnel
 * - Classifies traffic between internal subsystems and external apps
 * - Applies tracker detection and blocking policies
 * - Enforces routing rules (Direct/Tor/I2P/Block)
 * - Prevents DNS leaks and other privacy vulnerabilities
 * 
 * Critical Architecture Points:
 * - Single VPNService instance only
 * - Internal subsystems (Tor/I2P/DNSCrypt) bypass tracker filtering
 * - External apps undergo full privacy protection pipeline
 * - Strict traffic isolation between internal and external traffic
 */
@AndroidEntryPoint
class VPNService : VpnService() {
    
    @Inject
    lateinit var vpnCore: VPNCore
    
    @Inject
    lateinit var packetProcessor: PacketProcessor
    
    @Inject
    lateinit var routingEngine: RoutingEngine
    
    private var vpnInterface: ParcelFileDescriptor? = null
    private var vpnInput: FileInputStream? = null
    private var vpnOutput: FileOutputStream? = null
    
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var processingJob: Job? = null
    
    private var isRunning = false
    
    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "VPN Service created")
        
        // Initialize VPN core
        vpnCore.initialize(this)
        
        // Start foreground notification
        startForeground(NOTIFICATION_ID, createNotification())
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "VPN Service started")
        
        if (!isRunning) {
            startVPN()
        }
        
        return START_STICKY
    }
    
    private fun startVPN() {
        try {
            // Configure and establish VPN
            val builder = Builder()
                .setSession("Invizible Tracker Control Pro")
                .addAddress(VPN_ADDRESS, VPN_PREFIX_LENGTH)
                .addRoute("0.0.0.0", 0) // Route all traffic
                .addDnsServer(DNSCRYPT_DNS_SERVER)
                .setBlocking(true)
                .setConfigureIntent(createConfigureIntent())
            
            // Allow bypass for selected apps (internal subsystems)
            builder.addDisallowedApplication(packageName)
            
            // Establish VPN interface
            vpnInterface = builder.establish()
            
            if (vpnInterface != null) {
                vpnInput = FileInputStream(vpnInterface!!.fileDescriptor)
                vpnOutput = FileOutputStream(vpnInterface!!.fileDescriptor)
                
                isRunning = true
                
                // Start packet processing
                startPacketProcessing()
                
                Log.d(TAG, "VPN started successfully")
            } else {
                Log.e(TAG, "Failed to establish VPN interface")
                stopSelf()
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "Error starting VPN", e)
            stopSelf()
        }
    }
    
    private fun startPacketProcessing() {
        processingJob = serviceScope.launch {
            val buffer = ByteArray(MAX_PACKET_SIZE)
            
            while (isRunning && vpnInterface != null) {
                try {
                    // Read packet from VPN interface
                    val length = vpnInput!!.read(buffer)
                    
                    if (length > 0) {
                        val packetData = buffer.copyOf(length)
                        
                        // Process packet in coroutine
                        launch {
                            processPacket(packetData)
                        }
                    }
                    
                } catch (e: Exception) {
                    if (isRunning) {
                        Log.e(TAG, "Error reading packet", e)
                    }
                }
            }
        }
    }
    
    private suspend fun processPacket(packetData: ByteArray) {
        try {
            // Parse packet
            val packet = packetProcessor.parsePacket(packetData)
            
            // Classify traffic
            val classification = vpnCore.classifyTraffic(packet)
            
            when (classification.type) {
                TrafficType.INTERNAL_SUBSYSTEM -> {
                    // CRITICAL: Bypass all tracker logic for internal subsystems
                    routeInternalSubsystem(packet, classification)
                }
                
                TrafficType.EXTERNAL_APP -> {
                    // Apply full privacy protection pipeline
                    processExternalApp(packet, classification)
                }
                
                TrafficType.SYSTEM_APP -> {
                    // Apply user-defined policy for system apps
                    processSystemApp(packet, classification)
                }
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "Error processing packet", e)
        }
    }
    
    private fun routeInternalSubsystem(packet: Packet, classification: TrafficClassification) {
        // CRITICAL: Internal subsystems bypass ALL tracker logic
        
        try {
            // Direct routing for internal traffic
            val route = vpnCore.determineInternalRoute(packet)
            
            when (route) {
                InternalRoute.DNSCRYPT_DNS -> {
                    forwardToDNSCrypt(packet)
                }
                InternalRoute.TOR_DNS -> {
                    forwardToTorDNS(packet)
                }
                InternalRoute.TOR_SOCKS -> {
                    forwardToTorSOCKS(packet)
                }
                InternalRoute.I2P -> {
                    forwardToI2P(packet)
                }
                InternalRoute.DIRECT -> {
                    forwardDirect(packet)
                }
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "Error routing internal subsystem", e)
        }
    }
    
    private fun processExternalApp(packet: Packet, classification: TrafficClassification) {
        try {
            // Apply tracker detection
            val trackerResult = vpnCore.detectTrackers(packet, classification.appInfo)
            
            if (trackerResult.isTracker && trackerResult.shouldBlock) {
                // Block tracker traffic
                Log.d(TAG, "Blocked tracker: ${trackerResult.domain}")
                return
            }
            
            // Apply routing policy
            val route = classification.appInfo.routingPolicy.route
            
            when (route) {
                Route.TOR -> routeThroughTor(packet)
                Route.I2P -> routeThroughI2P(packet)
                Route.DIRECT -> routeDirect(packet)
                Route.BLOCK -> {
                    Log.d(TAG, "Blocked app: ${classification.appInfo.packageName}")
                    return
                }
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "Error processing external app", e)
        }
    }
    
    private fun processSystemApp(packet: Packet, classification: TrafficClassification) {
        // Apply user-defined policy for system apps
        if (classification.appInfo.isVPNBypassEnabled) {
            forwardDirect(packet)
        } else {
            processExternalApp(packet, classification)
        }
    }
    
    private fun forwardToDNSCrypt(packet: Packet) {
        // Forward to DNSCrypt resolver at 127.0.0.1:5353
        routingEngine.routeToDNSCrypt(packet)
    }
    
    private fun forwardToTorDNS(packet: Packet) {
        // Forward to Tor DNS resolver at 127.0.0.1:5400
        routingEngine.routeToTorDNS(packet)
    }
    
    private fun forwardToTorSOCKS(packet: Packet) {
        // Forward to Tor SOCKS proxy at 127.0.0.1:9050
        routingEngine.routeToTorSOCKS(packet)
    }
    
    private fun forwardToI2P(packet: Packet) {
        // Forward to I2P tunnel
        routingEngine.routeToI2P(packet)
    }
    
    private fun routeThroughTor(packet: Packet) {
        // Route through Tor for anonymity
        routingEngine.routeThroughTor(packet)
    }
    
    private fun routeThroughI2P(packet: Packet) {
        // Route through I2P network
        routingEngine.routeThroughI2P(packet)
    }
    
    private fun routeDirect(packet: Packet) {
        // Direct internet access
        routingEngine.routeDirect(packet)
    }
    
    private fun forwardDirect(packet: Packet) {
        // Forward packet directly to network
        try {
            val response = packetProcessor.forwardPacket(packet)
            if (response != null) {
                vpnOutput!!.write(response)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error forwarding packet", e)
        }
    }
    
    private fun createNotification(): android.app.Notification {
        // Create persistent notification for foreground service
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_IMMUTABLE
        )
        
        return android.app.Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Invizible Tracker Control Pro")
            .setContentText("VPN is active and protecting your privacy")
            .setSmallIcon(android.R.drawable.ic_secure)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }
    
    private fun createConfigureIntent(): PendingIntent {
        val intent = Intent(this, MainActivity::class.java)
        return PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_IMMUTABLE
        )
    }
    
    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "VPN Service destroyed")
        
        isRunning = false
        processingJob?.cancel()
        serviceScope.cancel()
        
        // Clean up resources
        vpnInterface?.close()
        vpnInput?.close()
        vpnOutput?.close()
    }
    
    companion object {
        private const val TAG = "VPNService"
        
        // VPN Configuration
        private const val VPN_ADDRESS = "10.0.0.1"
        private const val VPN_PREFIX_LENGTH = 32
        private const val MAX_PACKET_SIZE = 65536
        private const val NOTIFICATION_ID = 1
        private const val CHANNEL_ID = "vpn_service"
        
        // DNS Servers
        private const val DNSCRYPT_DNS_SERVER = "127.0.0.1:5353"
        
        // Service control methods
        fun start(context: Context) {
            val intent = Intent(context, VPNService::class.java)
            context.startService(intent)
        }
        
        fun stop(context: Context) {
            val intent = Intent(context, VPNService::class.java)
            context.stopService(intent)
        }
    }
}