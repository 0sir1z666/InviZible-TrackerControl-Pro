package com.invizible.trackercontrol

import android.app.Application
import android.content.Context
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

/**
 * Main application class for Invizible Tracker Control Pro
 * 
 * This application provides comprehensive privacy protection by combining:
 * - DNSCrypt for encrypted DNS resolution
 * - Tor for anonymous internet access
 * - I2P for anonymous peer-to-peer communication
 * - TrackerControl for per-app tracker detection and blocking
 * 
 * Core Architecture:
 * - Single VPNService instance manages all traffic
 * - Internal subsystems (Tor/I2P/DNSCrypt) bypass tracker filtering
 * - External apps undergo tracker detection and policy enforcement
 * - Strict process isolation for security
 */
@HiltAndroidApp
class TrackerControlApplication : Application(), Configuration.Provider {
    
    @Inject
    lateinit var workerFactory: HiltWorkerFactory
    
    override fun onCreate() {
        super.onCreate()
        
        // Initialize application-wide components
        initializeSecurity()
        initializeLogging()
        initializeServices()
    }
    
    private fun initializeSecurity() {
        // Set up security policies
        // This would include:
        // - Process isolation
        // - Secure IPC
        // - Configuration integrity
    }
    
    private fun initializeLogging() {
        // Set up secure logging
        // This would include:
        // - Security event logging
        // - Privacy-preserving analytics
        // - Debug logging (development only)
    }
    
    private fun initializeServices() {
        // Initialize background services
        // This would include:
        // - VPN service preparation
        // - Tracker database updates
        // - Configuration sync
    }
    
    override fun getWorkManagerConfiguration(): Configuration {
        return Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()
    }
    
    companion object {
        const val TAG = "TrackerControl"
        
        fun getAppContext(): Context {
            return instance.applicationContext
        }
        
        private lateinit var instance: TrackerControlApplication
        
        fun getInstance(): TrackerControlApplication {
            return instance
        }
    }
    
    init {
        instance = this
    }
}