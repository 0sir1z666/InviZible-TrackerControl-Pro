package com.invizible.trackercontrol.data.model

import com.invizible.core.routing.Route
import com.invizible.core.routing.RoutingPolicy

/**
 * Data model representing an Android application
 * with privacy and routing configuration
 */
data class App(
    val packageName: String,
    val name: String,
    val uid: Int,
    val isSystemApp: Boolean,
    val icon: ByteArray? = null,
    val routingPolicy: RoutingPolicy = RoutingPolicy(Route.DIRECT, true),
    val trackerSettings: TrackerSettings = TrackerSettings(),
    val networkStats: NetworkStats = NetworkStats(),
    val isEnabled: Boolean = true,
    val lastUsed: Long = 0L
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as App

        if (packageName != other.packageName) return false

        return true
    }

    override fun hashCode(): Int {
        return packageName.hashCode()
    }
}

/**
 * Tracker-specific settings for an app
 */
data class TrackerSettings(
    val blockTrackers: Boolean = true,
    val allowedTrackers: Set<String> = emptySet(),
    val blockedTrackers: Set<String> = emptySet(),
    val blockTrackingSDKs: Boolean = true
)

/**
 * Network usage statistics for an app
 */
data class NetworkStats(
    val bytesSent: Long = 0L,
    val bytesReceived: Long = 0L,
    val packetsSent: Long = 0L,
    val packetsReceived: Long = 0L,
    val trackersBlocked: Int = 0,
    val connectionsEstablished: Int = 0,
    val lastActivity: Long = 0L
)

/**
 * App category for policy management
 */
enum class AppCategory {
    BROWSER,
    SOCIAL,
    BANKING,
    GAMING,
    EMAIL,
    MESSAGING,
    UTILITY,
    PRODUCTIVITY,
    ENTERTAINMENT,
    HEALTH,
    FINANCE,
    SHOPPING,
    TRAVEL,
    EDUCATION,
    NEWS,
    WEATHER,
    MAPS,
    OTHER
}

/**
 * App permission information
 */
data class AppPermissions(
    val hasInternetPermission: Boolean = false,
    val hasNetworkPermission: Boolean = false,
    val hasLocationPermission: Boolean = false,
    val hasCameraPermission: Boolean = false,
    val hasMicrophonePermission: Boolean = false,
    val hasStoragePermission: Boolean = false,
    val hasContactsPermission: Boolean = false
)