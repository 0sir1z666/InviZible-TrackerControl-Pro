package com.invizible.trackercontrol.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.invizible.trackercontrol.ui.apps.AppManagementScreen
import com.invizible.trackercontrol.ui.dashboard.DashboardScreen
import com.invizible.trackercontrol.ui.logs.LogsScreen
import com.invizible.trackercontrol.ui.settings.SettingsScreen

/**
 * Navigation graph for Invizible Tracker Control Pro
 * 
 * Defines all navigation routes and screens in the application
 */
@Composable
fun MainNavHost(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = Screen.Dashboard.route
    ) {
        // Dashboard Screen
        composable(Screen.Dashboard.route) {
            DashboardScreen(navController = navController)
        }
        
        // App Management Screen
        composable(Screen.AppManagement.route) {
            AppManagementScreen(navController = navController)
        }
        
        // Settings Screen
        composable(Screen.Settings.route) {
            SettingsScreen(navController = navController)
        }
        
        // Logs Screen
        composable(Screen.Logs.route) {
            LogsScreen(navController = navController)
        }
        
        // App Detail Screen (with package name parameter)
        composable(
            route = Screen.AppDetail.route,
            arguments = Screen.AppDetail.arguments
        ) { backStackEntry ->
            val packageName = backStackEntry.arguments?.getString("packageName") ?: ""
            // AppDetailScreen(packageName = packageName, navController = navController)
        }
    }
}

/**
 * Screen definitions for navigation
 */
sealed class Screen(val route: String) {
    object Dashboard : Screen("dashboard")
    object AppManagement : Screen("app_management")
    object Settings : Screen("settings")
    object Logs : Screen("logs")
    
    object AppDetail : Screen("app_detail/{packageName}") {
        val arguments = listOf(
            androidx.navigation.NavArgument.Builder()
                .setName("packageName")
                .setType(androidx.navigation.NavType.StringType)
                .build()
        )
        
        fun createRoute(packageName: String): String {
            return "app_detail/$packageName"
        }
    }
}