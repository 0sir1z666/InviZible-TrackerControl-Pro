# Invizible Tracker Control Pro

A comprehensive Android privacy application that combines DNSCrypt, Tor, I2P, and tracker blocking in a single, unified solution.

## Features

### Core Privacy Protection
- **DNSCrypt**: Encrypted DNS resolution to prevent DNS hijacking and monitoring
- **Tor Integration**: Anonymous internet access through the Tor network
- **I2P Network**: Anonymous peer-to-peer communication
- **Tracker Control**: Per-app tracker detection and blocking

### Advanced Architecture
- **Single VPN Service**: One VPNService instance manages all traffic
- **Process Isolation**: Internal subsystems run in separate processes
- **Traffic Classification**: Intelligent routing based on app policies
- **Security First**: Comprehensive leak prevention and security measures

### Key Capabilities
- Per-app routing policies (Direct/Tor/I2P/Block)
- Real-time tracker blocking with offline database
- DNS leak prevention
- Tor fingerprinting protection
- Circular routing prevention
- Battery-optimized design

## Project Structure

```
InvizibleTrackerControl/
├── app/                    # Main application module
│   ├── src/main/java/     # Kotlin source code
│   │   ├── MainActivity.kt
│   │   ├── TrackerControlApplication.kt
│   │   ├── service/       # Android services
│   │   ├── ui/           # UI components (Compose)
│   │   ├── data/         # Data layer
│   │   └── utils/        # Utility classes
│   └── build.gradle.kts   # App module build script
├── core/                  # Core VPN infrastructure
├── tracker/               # Tracker detection engine
├── dnscrypt/              # DNSCrypt implementation
├── tor/                   # Tor integration
├── i2p/                   # I2P integration
└── build.gradle.kts       # Root build script
```

## Architecture

### Traffic Pipeline
```
External App → VPN Service → Traffic Classification → Policy Enforcement → Routing → Network
```

### Internal Subsystem Bypass
```
Tor/I2P/DNSCrypt → Direct Network Access → No Inspection → No Blocking
```

### Security Layers
1. **Process Isolation**: Separate processes for internal subsystems
2. **Traffic Isolation**: No mixing of internal and external traffic
3. **Configuration Security**: Encrypted preferences and certificate pinning
4. **Leak Prevention**: DNS, IP, and timing attack protection

## Building

### Prerequisites
- Android Studio Hedgehog or later
- JDK 17 or later
- Android SDK API 34
- Kotlin 1.9.10

### Build Commands
```bash
# Build debug APK
./gradlew assembleDebug

# Build release APK
./gradlew assembleRelease

# Install on connected device
./gradlew installDebug

# Run tests
./gradlew test
```

## Configuration

### VPN Service
- Single VPNService instance manages all traffic
- Traffic classification happens within the VPN tunnel
- Internal subsystems bypass all tracker logic

### DNS Resolution
- DNSCrypt for direct-routed apps (127.0.0.1:5353)
- Tor DNS for Tor-routed apps (127.0.0.1:5400)
- I2P DNS for I2P-routed apps (127.0.0.1:7653)

### Routing Policies
- **Direct**: Normal internet with tracker blocking
- **Tor**: Anonymous routing through Tor network
- **I2P**: Anonymous routing through I2P network
- **Block**: No internet access

## Security Features

### DNS Leak Prevention
- Force appropriate DNS resolver based on routing policy
- Block unauthorized DNS queries
- Validate DNS responses

### Tor Fingerprinting Protection
- Normalize packet parameters
- Standardize TLS fingerprints
- Add timing obfuscation

### Circular Routing Prevention
- Detect and block routing loops
- Limit maximum routing hops
- Monitor for suspicious patterns

### Process Isolation
- Internal services in separate processes
- Inter-process communication security
- Capability-based access control

## Privacy Considerations

### No Data Collection
- No telemetry or analytics
- Local-only operation
- Open source transparency

### Tracker Database
- Offline, signed tracker database
- Regular updates for new trackers
- User-controlled blocking policies

### Network Privacy
- Encrypted DNS queries
- Anonymous routing options
- Tracker blocking by default

## Performance Optimizations

### Battery Efficiency
- Adaptive polling intervals
- Batch packet processing
- Efficient wake-lock management

### Memory Management
- Stream-based packet processing
- Limited buffer sizes
- Aggressive garbage collection

### Network Performance
- Connection pooling
- Efficient routing algorithms
- Minimal packet overhead

## Testing

### Unit Tests
- Core functionality tests
- Policy engine tests
- Security validation tests

### Integration Tests
- VPN service tests
- Inter-module communication tests
- End-to-end privacy tests

### Security Tests
- Leak prevention tests
- Fingerprinting resistance tests
- Attack vector validation

## Contributing

1. Follow Android development guidelines
2. Maintain security-first approach
3. Add appropriate tests
4. Document architectural decisions
5. Respect user privacy

## License

This project is licensed under the GPL-3.0 License - see the LICENSE file for details.

## Acknowledgments

- Tor Project for anonymous networking
- DNSCrypt Project for encrypted DNS
- I2P Project for anonymous communication
- TrackerControl for tracker blocking inspiration
- Android Open Source Project for the platform

---

**Invizible Tracker Control Pro** - Complete privacy protection for Android