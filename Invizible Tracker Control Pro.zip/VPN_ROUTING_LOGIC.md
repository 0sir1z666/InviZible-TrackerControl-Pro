# Invizible Tracker Control Pro - VPN Routing Logic

## Core VPN Service Pseudocode

### Main VPN Service Loop

```kotlin
class VPNService : VpnService() {
    
    // Main packet processing loop
    fun processPackets() {
        while (vpnActive) {
            // Read packet from VPN interface
            val packet = vpnInterface.readPacket()
            
            // Classify traffic source
            val classification = classifyTraffic(packet)
            
            when (classification.type) {
                TrafficType.INTERNAL_SUBSYSTEM -> {
                    // BYPASS ALL TRACKER LOGIC
                    routeInternalSubsystem(packet, classification)
                }
                TrafficType.EXTERNAL_APP -> {
                    // Apply tracker detection and filtering
                    processExternalApp(packet, classification)
                }
                TrafficType.SYSTEM_APP -> {
                    // Apply user-defined policy
                    processSystemApp(packet, classification)
                }
            }
        }
    }
    
    // Traffic classification logic
    fun classifyTraffic(packet: Packet): TrafficClassification {
        val sourceAddr = packet.sourceAddress
        val sourcePort = packet.sourcePort
        val destAddr = packet.destinationAddress
        val destPort = packet.destinationPort
        
        // Check if traffic originates from internal subsystems
        if (isInternalSubsystem(sourceAddr, sourcePort)) {
            return TrafficClassification(
                type = TrafficType.INTERNAL_SUBSYSTEM,
                appInfo = null,
                route = Route.DIRECT_BYPASS
            )
        }
        
        // Get app info for external traffic
        val appInfo = getAppForConnection(sourceAddr, sourcePort)
        
        return if (appInfo.isSystemApp) {
            TrafficClassification(
                type = TrafficType.SYSTEM_APP,
                appInfo = appInfo,
                route = getSystemAppRoute(appInfo)
            )
        } else {
            TrafficClassification(
                type = TrafficType.EXTERNAL_APP,
                appInfo = appInfo,
                route = getAppRoute(appInfo)
            )
        }
    }
    
    // Internal subsystem bypass routing
    fun routeInternalSubsystem(packet: Packet, classification: TrafficClassification) {
        // CRITICAL: No tracker detection for internal subsystems
        
        // Direct pass-through for internal traffic
        val route = determineInternalRoute(packet)
        
        when (route) {
            InternalRoute.DNSCRYPT_DNS -> {
                // Route to DNSCrypt resolver
                sendToDNSCrypt(packet)
            }
            InternalRoute.TOR_DNS -> {
                // Route to Tor DNS resolver
                sendToTorDNS(packet)
            }
            InternalRoute.TOR_SOCKS -> {
                // Route to Tor SOCKS proxy
                sendToTorSOCKS(packet)
            }
            InternalRoute.I2P -> {
                // Route to I2P tunnel
                sendToI2P(packet)
            }
            InternalRoute.DIRECT -> {
                // Direct network access
                sendToNetwork(packet)
            }
        }
    }
    
    // External app processing with tracker detection
    fun processExternalApp(packet: Packet, classification: TrafficClassification) {
        val appInfo = classification.appInfo
        
        // Step 1: Check if app is blocked
        if (isAppBlocked(appInfo)) {
            dropPacket(packet)
            logBlockedApp(appInfo, packet)
            return
        }
        
        // Step 2: Check if destination is tracker
        if (packet.isDNSQuery) {
            processDNSQuery(packet, appInfo)
        } else {
            processAppTraffic(packet, appInfo)
        }
    }
    
    // DNS query processing for external apps
    fun processDNSQuery(packet: Packet, appInfo: AppInfo) {
        val domain = extractDomain(packet)
        
        // Check if domain is tracker
        if (isTrackerDomain(domain)) {
            val shouldBlock = shouldBlockTracker(appInfo, domain)
            
            if (shouldBlock) {
                // Block tracker DNS query
                sendDNSRefused(packet)
                logBlockedTracker(appInfo, domain)
                return
            }
        }
        
        // Route to appropriate DNS resolver
        routeDNSQuery(packet, appInfo)
    }
    
    // App traffic processing
    fun processAppTraffic(packet: Packet, appInfo: AppInfo) {
        val destination = packet.destinationAddress
        
        // Check if destination IP belongs to tracker
        if (isTrackerIP(destination)) {
            val shouldBlock = shouldBlockTracker(appInfo, destination)
            
            if (shouldBlock) {
                dropPacket(packet)
                logBlockedTracker(appInfo, destination)
                return
            }
        }
        
        // Route based on app routing policy
        routeAppTraffic(packet, appInfo)
    }
}
```

## Traffic Classification Logic

```kotlin
// Traffic classification implementation
class TrafficClassifier {
    
    // Internal subsystem detection
    fun isInternalSubsystem(sourceAddr: String, sourcePort: Int): Boolean {
        // DNSCrypt process
        if (sourceAddr == "127.0.0.1" && sourcePort == DNSCRYPT_SOURCE_PORT) {
            return true
        }
        
        // Tor process
        if (sourceAddr == "127.0.0.1" && 
            (sourcePort in TOR_SOURCE_PORT_RANGE || 
             sourcePort == TOR_DNS_PORT)) {
            return true
        }
        
        // I2P process
        if (sourceAddr == "127.0.0.1" && 
            sourcePort in I2P_SOURCE_PORT_RANGE) {
            return true
        }
        
        return false
    }
    
    // Get app info from connection
    fun getAppForConnection(sourceAddr: String, sourcePort: Int): AppInfo {
        // Query Android's connection tracking
        val connectionInfo = queryConnectionMap(sourceAddr, sourcePort)
        
        // Get app from UID
        val packageManager = context.packageManager
        val appName = packageManager.getNameForUid(connectionInfo.uid)
        
        return AppInfo(
            packageName = appName,
            uid = connectionInfo.uid,
            isSystemApp = isSystemApp(connectionInfo.uid),
            routingPolicy = getAppRoutingPolicy(appName)
        )
    }
    
    // Determine internal subsystem route
    fun determineInternalRoute(packet: Packet): InternalRoute {
        val destPort = packet.destinationPort
        
        return when {
            // DNS queries from internal subsystems
            packet.isDNSQuery -> {
                when {
                    destPort == DNSCRYPT_DNS_PORT -> InternalRoute.DNSCRYPT_DNS
                    destPort == TOR_DNS_PORT -> InternalRoute.TOR_DNS
                    destPort == I2P_DNS_PORT -> InternalRoute.I2P_DNS
                    else -> InternalRoute.DIRECT
                }
            }
            
            // SOCKS traffic to Tor
            destPort == TOR_SOCKS_PORT -> InternalRoute.TOR_SOCKS
            
            // I2P traffic
            destPort in I2P_PORT_RANGE -> InternalRoute.I2P
            
            // Default direct route
            else -> InternalRoute.DIRECT
        }
    }
}
```

## DNS Resolution Logic

```kotlin
// DNS resolution strategy
class DNSResolver {
    
    fun routeDNSQuery(packet: Packet, appInfo: AppInfo) {
        val routingPolicy = appInfo.routingPolicy
        
        when (routingPolicy.route) {
            Route.TOR -> {
                // Route to Tor DNS resolver
                // IMPORTANT: No DNSCrypt for Tor apps
                forwardToTorDNS(packet)
            }
            
            Route.I2P -> {
                // Route to I2P DNS resolver
                forwardToI2PDNS(packet)
            }
            
            Route.DIRECT -> {
                // Route to DNSCrypt resolver
                forwardToDNSCrypt(packet)
            }
            
            Route.BLOCK -> {
                // Block all DNS queries
                sendDNSRefused(packet)
            }
        }
    }
    
    fun forwardToDNSCrypt(packet: Packet) {
        // Send to DNSCrypt resolver at 127.0.0.1:5353
        val dnscryptSocket = Socket("127.0.0.1", 5353)
        dnscryptSocket.send(packet.payload)
        
        // Forward response back to app
        val response = dnscryptSocket.receive()
        vpnInterface.writePacket(buildDNSResponse(packet, response))
    }
    
    fun forwardToTorDNS(packet: Packet) {
        // Send to Tor DNS resolver at 127.0.0.1:5400
        val torDNSSocket = Socket("127.0.0.1", 5400)
        torDNSSocket.send(packet.payload)
        
        // Forward response back to app
        val response = torDNSSocket.receive()
        vpnInterface.writePacket(buildDNSResponse(packet, response))
    }
    
    fun forwardToI2PDNS(packet: Packet) {
        // Send to I2P DNS resolver at 127.0.0.1:7653
        val i2pDNSSocket = Socket("127.0.0.1", 7653)
        i2pDNSSocket.send(packet.payload)
        
        // Forward response back to app
        val response = i2pDNSSocket.receive()
        vpnInterface.writePacket(buildDNSResponse(packet, response))
    }
}
```

## Routing Engine Logic

```kotlin
// Routing decision engine
class RoutingEngine {
    
    fun routeAppTraffic(packet: Packet, appInfo: AppInfo) {
        val routingPolicy = appInfo.routingPolicy
        
        when (routingPolicy.route) {
            Route.TOR -> {
                // Route through Tor SOCKS proxy
                routeThroughTor(packet)
            }
            
            Route.I2P -> {
                // Route through I2P tunnel
                routeThroughI2P(packet)
            }
            
            Route.DIRECT -> {
                // Direct internet access
                routeDirect(packet)
            }
            
            Route.BLOCK -> {
                // Block all traffic
                dropPacket(packet)
            }
        }
    }
    
    fun routeThroughTor(packet: Packet) {
        // Send to Tor SOCKS proxy at 127.0.0.1:9050
        val torSocket = Socket("127.0.0.1", 9050)
        
        // SOCKS5 handshake
        performSOCKS5Handshake(torSocket, packet.destinationAddress, packet.destinationPort)
        
        // Forward packet payload
        torSocket.send(packet.payload)
        
        // Relay response back to app
        relayTraffic(torSocket, packet)
    }
    
    fun routeThroughI2P(packet: Packet) {
        // Send to I2P SOCKS proxy at 127.0.0.1:7654
        val i2pSocket = Socket("127.0.0.1", 7654)
        
        // I2P SOCKS handshake
        performI2PSOCKSHandshake(i2pSocket, packet.destinationAddress, packet.destinationPort)
        
        // Forward packet payload
        i2pSocket.send(packet.payload)
        
        // Relay response back to app
        relayTraffic(i2pSocket, packet)
    }
    
    fun routeDirect(packet: Packet) {
        // Direct network access
        val targetSocket = Socket(packet.destinationAddress, packet.destinationPort)
        targetSocket.send(packet.payload)
        
        // Relay response back to app
        relayTraffic(targetSocket, packet)
    }
}
```

## Tracker Detection Logic

```kotlin
// Tracker detection engine
class TrackerDetector {
    
    fun isTrackerDomain(domain: String): Boolean {
        // Query tracker database
        return trackerDatabase.queryDomain(domain) != null
    }
    
    fun isTrackerIP(ip: String): Boolean {
        // Query tracker IP database
        return trackerDatabase.queryIP(ip) != null
    }
    
    fun shouldBlockTracker(appInfo: AppInfo, tracker: String): Boolean {
        // Check app-specific tracker rules
        val appRules = appRuleDatabase.getRules(appInfo.packageName)
        
        // Check if tracker is in app-specific allowlist
        if (appRules.allowedTrackers.contains(tracker)) {
            return false
        }
        
        // Check if tracker is in app-specific blocklist
        if (appRules.blockedTrackers.contains(tracker)) {
            return true
        }
        
        // Apply global tracker blocking policy
        return settings.isTrackerBlockingEnabled
    }
    
    fun isTrackerSDK(packageName: String): Boolean {
        // Check if app contains known tracker SDKs
        val appInfo = packageManager.getPackageInfo(packageName, 0)
        val signatures = appInfo.signatures
        
        return trackerDatabase.querySDK(signatures) != null
    }
}
```

## Firewall Logic

```kotlin
// Firewall engine
class FirewallEngine {
    
    fun isAppBlocked(appInfo: AppInfo): Boolean {
        // Check if app is completely blocked
        val appRules = appRuleDatabase.getRules(appInfo.packageName)
        return appRules.isBlocked
    }
    
    fun shouldAllowConnection(appInfo: AppInfo, destination: String, port: Int): Boolean {
        // Check app-specific firewall rules
        val appRules = appRuleDatabase.getRules(appInfo.packageName)
        
        // Check port-based rules
        if (appRules.blockedPorts.contains(port)) {
            return false
        }
        
        // Check destination-based rules
        if (appRules.blockedDestinations.contains(destination)) {
            return false
        }
        
        // Apply default policy
        return true
    }
    
    fun logBlockedTraffic(appInfo: AppInfo, packet: Packet) {
        val logEntry = FirewallLogEntry(
            timestamp = System.currentTimeMillis(),
            appInfo = appInfo,
            destination = packet.destinationAddress,
            port = packet.destinationPort,
            reason = getBlockReason(appInfo, packet)
        )
        
        firewallLog.addEntry(logEntry)
    }
}
```

## Connection Tracking

```kotlin
// Connection tracking for accurate app identification
class ConnectionTracker {
    
    private val connectionMap = mutableMapOf<ConnectionKey, AppInfo>()
    
    data class ConnectionKey(
        val sourceAddr: String,
        val sourcePort: Int,
        val protocol: Int
    )
    
    fun trackConnection(packet: Packet, appInfo: AppInfo) {
        val key = ConnectionKey(
            sourceAddr = packet.sourceAddress,
            sourcePort = packet.sourcePort,
            protocol = packet.protocol
        )
        
        connectionMap[key] = appInfo
        
        // Clean up old connections periodically
        cleanupOldConnections()
    }
    
    fun getAppForConnection(sourceAddr: String, sourcePort: Int): AppInfo? {
        val key = ConnectionKey(sourceAddr, sourcePort, Protocol.TCP)
        return connectionMap[key]
    }
    
    private fun cleanupOldConnections() {
        val currentTime = System.currentTimeMillis()
        val timeout = 300000 // 5 minutes
        
        connectionMap.entries.removeIf { entry ->
            (currentTime - entry.value.lastActivity) > timeout
        }
    }
}
```

## Security and Leak Prevention

```kotlin
// Security checks
class SecurityManager {
    
    fun preventDNSLeak(packet: Packet, appInfo: AppInfo) {
        // Ensure DNS queries use correct resolver based on routing policy
        if (packet.isDNSQuery) {
            when (appInfo.routingPolicy.route) {
                Route.TOR -> {
                    // Force Tor DNS
                    if (packet.destinationAddress != "127.0.0.1" || 
                        packet.destinationPort != 5400) {
                        redirectToTorDNS(packet)
                    }
                }
                Route.I2P -> {
                    // Force I2P DNS
                    if (packet.destinationAddress != "127.0.0.1" || 
                        packet.destinationPort != 7653) {
                        redirectToI2PDNS(packet)
                    }
                }
                Route.DIRECT -> {
                    // Force DNSCrypt
                    if (packet.destinationAddress != "127.0.0.1" || 
                        packet.destinationPort != 5353) {
                        redirectToDNSCrypt(packet)
                    }
                }
            }
        }
    }
    
    fun preventCircularRouting(packet: Packet) {
        // Check if packet is trying to route through VPN itself
        if (packet.destinationAddress == VPN_TUNNEL_ADDRESS) {
            dropPacket(packet)
            logSecurityEvent("Circular routing detected", packet)
        }
    }
    
    fun preventTorFingerprinting(packet: Packet, appInfo: AppInfo) {
        if (appInfo.routingPolicy.route == Route.TOR) {
            // Remove potential fingerprinting headers
            sanitizePacketHeaders(packet)
            
            // Ensure consistent MTU
            enforceMTU(packet, TOR_MTU)
        }
    }
}
```

This VPN routing logic ensures complete privacy protection while maintaining the strict separation between internal subsystems and external app traffic as specified in the requirements.