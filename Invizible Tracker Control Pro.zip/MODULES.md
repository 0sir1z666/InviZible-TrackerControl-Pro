# Invizible Tracker Control Pro - Module and Package Breakdown

## Project Structure

```
InvizibleTrackerControl/
├── app/
│   ├── src/main/
│   │   ├── java/com/invizible/trackercontrol/
│   │   │   ├── Application.kt
│   │   │   ├── MainActivity.kt
│   │   │   ├── ui/
│   │   │   │   ├── dashboard/
│   │   │   │   ├── apps/
│   │   │   │   ├── settings/
│   │   │   │   └── components/
│   │   │   ├── service/
│   │   │   │   ├── VPNService.kt
│   │   │   │   ├── DNSCryptService.kt
│   │   │   │   ├── TorService.kt
│   │   │   │   └── I2PService.kt
│   │   │   ├── core/
│   │   │   │   ├── packet/
│   │   │   │   ├── routing/
│   │   │   │   ├── dns/
│   │   │   │   └── firewall/
│   │   │   ├── data/
│   │   │   │   ├── database/
│   │   │   │   ├── repository/
│   │   │   │   └── model/
│   │   │   └── utils/
│   │   ├── res/
│   │   └── AndroidManifest.xml
│   └── build.gradle.kts
├── core/
│   ├── src/main/java/com/invizible/core/
│   │   ├── vpn/
│   │   ├── packet/
│   │   ├── routing/
│   │   └── common/
│   └── build.gradle.kts
├── tracker/
│   ├── src/main/java/com/invizible/tracker/
│   │   ├── detector/
│   │   ├── database/
│   │   └── rules/
│   └── build.gradle.kts
├── dnscrypt/
│   ├── src/main/java/com/invizible/dnscrypt/
│   │   ├── service/
│   │   ├── resolver/
│   │   └── config/
│   └── build.gradle.kts
├── tor/
│   ├── src/main/java/com/invizible/tor/
│   │   ├── service/
│   │   ├── control/
│   │   └── config/
│   └── build.gradle.kts
├── i2p/
│   ├── src/main/java/com/invizible/i2p/
│   │   ├── service/
│   │   ├── tunnel/
│   │   └── config/
│   └── build.gradle.kts
└── settings.gradle.kts
```

## Module Breakdown

### 1. **app** - Main Application Module
**Purpose**: UI layer, main activity, and application coordination

#### Key Components:
- `Application.kt`: Main application entry point
- `MainActivity.kt`: Dashboard activity
- `ui/`: All UI components following MVVM
- `service/`: Android service wrappers
- `core/`: Core application logic
- `data/`: Data layer (Room, repositories)
- `utils/`: Utility classes

#### Dependencies:
- All other modules
- AndroidX libraries
- Jetpack Compose/Material Design
- Lifecycle components

### 2. **core** - Core VPN Infrastructure
**Purpose**: Low-level VPN implementation and packet handling

#### Key Components:
- `vpn/`: VPNService implementation
- `packet/`: Packet parsing and construction
- `routing/`: Routing engine
- `common/`: Shared utilities

#### Classes:
```kotlin
// VPN Core Implementation
class VPNService : VpnService()
class PacketProcessor
class TrafficClassifier
class RoutingEngine
class DNSResolver
class FirewallEngine
```

#### Dependencies:
- Kotlin standard library
- Android framework APIs
- No external dependencies

### 3. **tracker** - Tracker Detection Engine
**Purpose**: SDK and domain-based tracker detection

#### Key Components:
- `detector/`: Tracker detection algorithms
- `database/`: Tracker database management
- `rules/`: Tracker blocking rules engine

#### Classes:
```kotlin
// Tracker Detection System
class TrackerDetector
class TrackerDatabase
class TrackerRuleEngine
class TrackerAllowList
class TrackerStatistics
```

#### Dependencies:
- Room database
- Kotlin coroutines
- Core module

### 4. **dnscrypt** - DNSCrypt Implementation
**Purpose**: DNSCrypt resolver service

#### Key Components:
- `service/`: DNSCrypt service management
- `resolver/`: DNSCrypt protocol implementation
- `config/`: DNSCrypt configuration

#### Classes:
```kotlin
// DNSCrypt Implementation
class DNSCryptService
class DNSCryptResolver
class DNSCryptConfig
class DNSCryptProcessManager
```

#### Dependencies:
- Native DNSCrypt libraries
- Process management APIs
- Configuration management

### 5. **tor** - Tor Integration
**Purpose**: Tor routing service

#### Key Components:
- `service/`: Tor service management
- `control/`: Tor control protocol
- `config/`: Tor configuration

#### Classes:
```kotlin
// Tor Implementation
class TorService
class TorController
class TorConfig
class TorProcessManager
```

#### Dependencies:
- Tor native libraries
- Process management APIs
- SOCKS proxy implementation

### 6. **i2p** - I2P Integration
**Purpose**: I2P routing service

#### Key Components:
- `service/`: I2P service management
- `tunnel/`: I2P tunnel management
- `config/`: I2P configuration

#### Classes:
```kotlin
// I2P Implementation
class I2PService
class I2PTunnelManager
class I2PConfig
class I2PProcessManager
```

#### Dependencies:
- I2P native libraries
- Process management APIs
- Tunnel management APIs

## Package Structure Details

### app/src/main/java/com/invizible/trackercontrol/

#### ui/
```
ui/
├── dashboard/
│   ├── DashboardScreen.kt
│   ├── DashboardViewModel.kt
│   └── DashboardState.kt
├── apps/
│   ├── AppListScreen.kt
│   ├── AppDetailScreen.kt
│   ├── AppViewModel.kt
│   └── components/
├── settings/
│   ├── SettingsScreen.kt
│   ├── SettingsViewModel.kt
│   └── components/
└── components/
    ├── Toggles.kt
    ├── Cards.kt
    └── CommonUI.kt
```

#### service/
```
service/
├── VPNService.kt           # Main VPN service
├── DNSCryptService.kt      # DNSCrypt service wrapper
├── TorService.kt           # Tor service wrapper
└── I2PService.kt           # I2P service wrapper
```

#### core/
```
core/
├── packet/
│   ├── PacketParser.kt
│   ├── PacketBuilder.kt
│   └── PacketQueue.kt
├── routing/
│   ├── RoutingEngine.kt
│   ├── RoutingPolicy.kt
│   └── RoutingTable.kt
├── dns/
│   ├── DNSResolver.kt
│   ├── DNSCache.kt
│   └── DNSQuery.kt
└── firewall/
    ├── FirewallEngine.kt
    ├── FirewallRules.kt
    └── FirewallLog.kt
```

#### data/
```
data/
├── database/
│   ├── AppDatabase.kt
│   ├── dao/
│   │   ├── AppDAO.kt
│   │   ├── TrackerDAO.kt
│   │   └── SettingsDAO.kt
│   └── entity/
│       ├── AppEntity.kt
│       ├── TrackerEntity.kt
│       └── SettingsEntity.kt
├── repository/
│   ├── AppRepository.kt
│   ├── TrackerRepository.kt
│   └── SettingsRepository.kt
└── model/
    ├── App.kt
    ├── Tracker.kt
    └── Settings.kt
```

### Inter-Module Communication

#### Module Dependencies Graph:
```
        app
       /   |   \
     /     |     \
   core  tracker   |
    |       |      |
 dnscrypt  tor    i2p
```

#### Communication Patterns:

1. **Service-to-Core Communication**:
```kotlin
// Service binds to Core module
interface VPNCore {
    fun startVPN(config: VPNConfig)
    fun stopVPN()
    fun updateRouting(policy: RoutingPolicy)
}
```

2. **Core-to-Tracker Communication**:
```kotlin
// Core queries tracker module
interface TrackerAPI {
    fun isTracker(domain: String): Boolean
    fun isTrackerSDK(packageName: String): Boolean
    fun shouldBlock(app: App, tracker: Tracker): Boolean
}
```

3. **Module-to-Module Communication**:
```kotlin
// Event bus for loose coupling
sealed class ModuleEvent {
    data class VPNStarted(val config: VPNConfig) : ModuleEvent()
    data class TrackerDetected(val app: App, val tracker: Tracker) : ModuleEvent()
    data class RoutingChanged(val app: App, val route: Route) : ModuleEvent()
}
```

## Data Flow Architecture

### 1. **UI to Service Flow**:
```
UI → ViewModel → Repository → Service → Core Module
```

### 2. **Packet Processing Flow**:
```
VPNService → TrafficClassifier → 
  ├─ Internal Subsystem → Direct Route
  └─ External App → TrackerDetector → 
      ├─ Blocked → Drop
      └─ Allowed → RoutingEngine → DNS → Network
```

### 3. **Configuration Flow**:
```
Settings UI → SettingsRepository → 
  ├─ VPNService (routing rules)
  ├─ TrackerModule (detection rules)
  └─ Internal Services (Tor/I2P/DNSCrypt configs)
```

## Security Architecture

### 1. **Process Isolation**:
- Each internal service runs in separate process
- Inter-process communication via AIDL/Binder
- Sandboxed execution environment

### 2. **Configuration Security**:
- Encrypted shared preferences for sensitive settings
- Certificate pinning for update mechanisms
- Secure bootstrapping for internal services

### 3. **Network Security**:
- No traffic inspection for internal subsystems
- Encrypted communication between modules
- Secure random for all cryptographic operations

## Performance Considerations

### 1. **Module Performance**:
- Core module: Minimal overhead packet processing
- Tracker module: Efficient pattern matching
- Internal services: Native performance

### 2. **Memory Management**:
- Lazy loading of tracker database
- Connection pooling for DNS queries
- Efficient buffer management

### 3. **Battery Optimization**:
- Adaptive polling intervals
- Batch processing where possible
- Efficient wake-lock management

This modular architecture ensures maintainability, security, and performance while meeting all the specified requirements for the Invizible Tracker Control Pro application.