# Invizible Tracker Control Pro - UI Screen Structure

## UI Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          UI NAVIGATION STRUCTURE                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                           MAIN ACTIVITY                              │   │
│  │                          (Dashboard Screen)                          │   │
│  │  ┌─────────────────────────────────────────────────────────────┐   │   │
│  │  │  Invizible Tracker Control Pro                              │   │   │
│  │  │  ─────────────────────────────                             │   │   │
│  │  │                                                              │   │   │
│  │  │  ┌─────────────────────────┐  ┌─────────────────────────┐  │   │   │
│  │  │  │   VPN Status Card       │  │  Quick Stats Card       │  │   │   │
│  │  │  │   [●] Connected         │  │  Apps Protected: 47     │  │   │   │
│  │  │  │   IP: 10.0.0.1          │  │  Trackers Blocked: 1.2K │  │   │   │
│  │  │  │   Duration: 2h 34m      │  │  Data Encrypted: 45MB  │  │   │   │
│  │  │  └─────────────────────────┘  └─────────────────────────┘  │   │   │
│  │  │                                                              │   │   │
│  │  │  ┌─────────────────────────────────────────────────────────┐ │   │   │
│  │  │  │  Global Toggles                                         │ │   │   │
│  │  │  │  ─────────────────                                    │ │   │   │
│  │  │  │                                                         │ │   │   │
│  │  │  │  [●] Tracker Control     [○] DNSCrypt                 │ │   │   │
│  │  │  │  [●] Tor                 [○] I2P                     │ │   │   │
│  │  │  │                                                         │ │   │   │
│  │  │  └─────────────────────────────────────────────────────────┘ │   │   │
│  │  │                                                              │   │   │
│  │  │  ┌─────────────────────────────────────────────────────────┐ │   │   │
│  │  │  │  Quick Actions                                          │ │   │   │
│  │  │  │  ────────────────                                     │ │   │   │
│  │  │  │                                                         │ │   │   │
│  │  │  │  [App Management]  [Settings]  [View Logs]           │ │   │   │
│  │  │  │                                                         │ │   │   │
│  │  │  └─────────────────────────────────────────────────────────┘ │   │   │
│  │  └─────────────────────────────────────────────────────────────┘   │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│              │                    │                    │                      │
│              ▼                    ▼                    ▼                      │
│  ┌─────────────────────┐  ┌───────────────┐  ┌───────────────┐            │
│  │   App Management    │  │   Settings    │  │     Logs      │            │
│  │       Screen        │  │    Screen     │  │    Screen     │            │
│  └─────────────────────┘  └───────────────┘  └───────────────┘            │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Main Dashboard Screen

### Screen Components:

```kotlin
@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // App Header
        AppHeader()
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Status Cards Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            VPNStatusCard(state.vpnStatus)
            QuickStatsCard(state.stats)
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Global Toggles Section
        GlobalTogglesSection(
            trackerControlEnabled = state.trackerControlEnabled,
            dnscryptEnabled = state.dnscryptEnabled,
            torEnabled = state.torEnabled,
            i2pEnabled = state.i2pEnabled,
            onToggleChanged = viewModel::onToggleChanged
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Quick Actions Section
        QuickActionsSection(
            onAppManagementClick = { /* Navigate to App Management */ },
            onSettingsClick = { /* Navigate to Settings */ },
            onLogsClick = { /* Navigate to Logs */ }
        )
    }
}
```

### Status Cards:

```kotlin
@Composable
fun VPNStatusCard(status: VPNStatus) {
    Card(
        modifier = Modifier
            .width(180.dp)
            .height(120.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = "VPN Status",
                    tint = if (status.isConnected) Color.Green else Color.Red
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (status.isConnected) "Connected" else "Disconnected",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            
            Text(
                text = "IP: ${status.virtualIP}",
                style = MaterialTheme.typography.bodySmall
            )
            
            Text(
                text = "Duration: ${status.duration}",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
fun QuickStatsCard(stats: AppStats) {
    Card(
        modifier = Modifier
            .width(180.dp)
            .height(120.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            StatItem(
                label = "Apps Protected",
                value = "${stats.appsProtected}",
                icon = Icons.Default.Apps
            )
            
            StatItem(
                label = "Trackers Blocked",
                value = formatNumber(stats.trackersBlocked),
                icon = Icons.Default.Block
            )
            
            StatItem(
                label = "Data Encrypted",
                value = formatBytes(stats.dataEncrypted),
                icon = Icons.Default.Security
            )
        }
    }
}
```

## App Management Screen

### Screen Structure:

```kotlin
@Composable
fun AppManagementScreen(
    viewModel: AppManagementViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()
    
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Top App Bar
        TopAppBar(
            title = { Text("App Management") },
            actions = {
                IconButton(onClick = { /* Search */ }) {
                    Icon(Icons.Default.Search, contentDescription = "Search")
                }
                IconButton(onClick = { /* Filter */ }) {
                    Icon(Icons.Default.FilterList, contentDescription = "Filter")
                }
            }
        )
        
        // Filter Chips
        FilterChips(
            selectedFilter = state.filter,
            onFilterChanged = viewModel::onFilterChanged
        )
        
        // App List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(state.apps) { app ->
                AppListItem(
                    app = app,
                    onAppClick = { /* Navigate to App Detail */ },
                    onToggleChanged = { enabled ->
                        viewModel.onAppToggleChanged(app.packageName, enabled)
                    }
                )
            }
        }
    }
}
```

### App List Item:

```kotlin
@Composable
fun AppListItem(
    app: AppInfo,
    onAppClick: () -> Unit,
    onToggleChanged: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onAppClick),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // App Icon
            AppIcon(
                packageName = app.packageName,
                modifier = Modifier.size(48.dp)
            )
            
            Spacer(modifier = Modifier.width(16.dp))
            
            // App Info
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = app.name,
                    style = MaterialTheme.typography.bodyLarge
                )
                
                Text(
                    text = "Routing: ${app.routingPolicy.route}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Block,
                        contentDescription = "Trackers Blocked",
                        modifier = Modifier.size(12.dp),
                        tint = if (app.trackersBlocked > 0) Color.Red else Color.Gray
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${app.trackersBlocked} trackers blocked",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (app.trackersBlocked > 0) Color.Red else Color.Gray
                    )
                }
            }
            
            // Toggle Switch
            Switch(
                checked = app.isEnabled,
                onCheckedChange = onToggleChanged
            )
        }
    }
}
```

## App Detail Screen

### Screen Components:

```kotlin
@Composable
fun AppDetailScreen(
    packageName: String,
    viewModel: AppDetailViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()
    
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Top App Bar
        TopAppBar(
            title = { Text(state.app.name) },
            navigationIcon = {
                IconButton(onClick = { /* Navigate back */ }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
            }
        )
        
        // App Header
        AppDetailHeader(app = state.app)
        
        // Tab Layout
        var selectedTab by remember { mutableStateOf(0) }
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Routing") }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Trackers") }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("Stats") }
            )
        }
        
        // Tab Content
        when (selectedTab) {
            0 -> RoutingTabContent(
                app = state.app,
                onRoutingChanged = viewModel::onRoutingChanged
            )
            1 -> TrackersTabContent(
                trackers = state.trackers,
                onTrackerToggle = viewModel::onTrackerToggle
            )
            2 -> StatsTabContent(stats = state.stats)
        }
    }
}
```

### Routing Tab:

```kotlin
@Composable
fun RoutingTabContent(
    app: AppInfo,
    onRoutingChanged: (Route) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Network Routing",
            style = MaterialTheme.typography.headlineSmall
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Routing Options
        RoutingOptionCard(
            route = Route.DIRECT,
            title = "Direct",
            description = "Connect directly to the internet",
            selected = app.routingPolicy.route == Route.DIRECT,
            onClick = { onRoutingChanged(Route.DIRECT) }
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        RoutingOptionCard(
            route = Route.TOR,
            title = "Tor Network",
            description = "Route through Tor for anonymity",
            selected = app.routingPolicy.route == Route.TOR,
            onClick = { onRoutingChanged(Route.TOR) }
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        RoutingOptionCard(
            route = Route.I2P,
            title = "I2P Network",
            description = "Route through I2P network",
            selected = app.routingPolicy.route == Route.I2P,
            onClick = { onRoutingChanged(Route.I2P) }
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        RoutingOptionCard(
            route = Route.BLOCK,
            title = "Block Internet",
            description = "Block all internet access",
            selected = app.routingPolicy.route == Route.BLOCK,
            onClick = { onRoutingChanged(Route.BLOCK) }
        )
    }
}
```

### Trackers Tab:

```kotlin
@Composable
fun TrackersTabContent(
    trackers: List<TrackerInfo>,
    onTrackerToggle: (String, Boolean) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Tracker Stats
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                StatColumn(
                    label = "Total",
                    value = "${trackers.size}"
                )
                StatColumn(
                    label = "Blocked",
                    value = "${trackers.count { it.isBlocked }}"
                )
                StatColumn(
                    label = "Allowed",
                    value = "${trackers.count { !it.isBlocked }}"
                )
            }
        }
        
        // Tracker List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(8.dp)
        ) {
            items(trackers) { tracker ->
                TrackerListItem(
                    tracker = tracker,
                    onToggle = { allowed ->
                        onTrackerToggle(tracker.domain, allowed)
                    }
                )
            }
        }
    }
}
```

## Settings Screen

### Screen Structure:

```kotlin
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()
    
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Top App Bar
        TopAppBar(
            title = { Text("Settings") }
        )
        
        // Settings List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(8.dp)
        ) {
            // VPN Settings
            item {
                SettingsCategoryHeader("VPN Settings")
            }
            
            item {
                SettingsToggleItem(
                    title = "Auto-start VPN",
                    checked = state.autoStartVPN,
                    onCheckedChange = viewModel::onAutoStartVPNChanged
                )
            }
            
            item {
                SettingsToggleItem(
                    title = "Kill switch",
                    checked = state.killSwitch,
                    onCheckedChange = viewModel::onKillSwitchChanged
                )
            }
            
            item {
                SettingsClickItem(
                    title = "VPN Protocol",
                    subtitle = state.vpnProtocol,
                    onClick = { /* Show protocol selection dialog */ }
                )
            }
            
            // Tracker Settings
            item {
                SettingsCategoryHeader("Tracker Settings")
            }
            
            item {
                SettingsToggleItem(
                    title = "Block trackers by default",
                    checked = state.blockTrackersByDefault,
                    onCheckedChange = viewModel::onBlockTrackersByDefaultChanged
                )
            }
            
            item {
                SettingsClickItem(
                    title = "Tracker database",
                    subtitle = "Last updated: ${state.trackerDbLastUpdated}",
                    onClick = { /* Update tracker database */ }
                )
            }
            
            // DNS Settings
            item {
                SettingsCategoryHeader("DNS Settings")
            }
            
            item {
                SettingsToggleItem(
                    title = "Enable DNSCrypt",
                    checked = state.dnsCryptEnabled,
                    onCheckedChange = viewModel::onDNSCryptEnabledChanged
                )
            }
            
            item {
                SettingsClickItem(
                    title = "DNSCrypt servers",
                    subtitle = "${state.dnsCryptServers.size} servers configured",
                    onClick = { /* Show DNSCrypt server selection */ }
                )
            }
            
            // Tor Settings
            item {
                SettingsCategoryHeader("Tor Settings")
            }
            
            item {
                SettingsToggleItem(
                    title = "Enable Tor",
                    checked = state.torEnabled,
                    onCheckedChange = viewModel::onTorEnabledChanged
                )
            }
            
            item {
                SettingsClickItem(
                    title = "Tor bridges",
                    subtitle = "Configure bridge relays",
                    onClick = { /* Show Tor bridge configuration */ }
                )
            }
            
            // I2P Settings
            item {
                SettingsCategoryHeader("I2P Settings")
            }
            
            item {
                SettingsToggleItem(
                    title = "Enable I2P",
                    checked = state.i2pEnabled,
                    onCheckedChange = viewModel::onI2PEnabledChanged
                )
            }
            
            // Advanced Settings
            item {
                SettingsCategoryHeader("Advanced")
            }
            
            item {
                SettingsClickItem(
                    title = "Export/Import settings",
                    subtitle = "Backup and restore configuration",
                    onClick = { /* Show export/import dialog */ }
                )
            }
            
            item {
                SettingsClickItem(
                    title = "Reset to defaults",
                    subtitle = "Restore factory settings",
                    onClick = { /* Show reset confirmation */ }
                )
            }
        }
    }
}
```

## Logs Screen

### Screen Components:

```kotlin
@Composable
fun LogsScreen(
    viewModel: LogsViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()
    
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Top App Bar with Filter
        TopAppBar(
            title = { Text("Connection Logs") },
            actions = {
                IconButton(onClick = { /* Clear logs */ }) {
                    Icon(Icons.Default.Delete, contentDescription = "Clear")
                }
                IconButton(onClick = { /* Export logs */ }) {
                    Icon(Icons.Default.Share, contentDescription = "Export")
                }
            }
        )
        
        // Filter Chips
        FilterChips(
            selectedFilter = state.logFilter,
            onFilterChanged = viewModel::onFilterChanged
        )
        
        // Log List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            reverseLayout = true // Show newest first
        ) {
            items(state.logs) { log ->
                LogListItem(log = log)
            }
        }
    }
}
```

## Common UI Components

### Toggle Component:

```kotlin
@Composable
fun GlobalToggle(
    title: String,
    description: String,
    enabled: Boolean,
    onToggle: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyLarge
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            
            Switch(
                checked = enabled,
                onCheckedChange = onToggle
            )
        }
    }
}
```

### App Icon Component:

```kotlin
@Composable
fun AppIcon(
    packageName: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val icon = remember(packageName) {
        try {
            context.packageManager.getApplicationIcon(packageName)
        } catch (e: PackageManager.NameNotFoundException) {
            ContextCompat.getDrawable(context, android.R.drawable.sym_def_app_icon)
        }
    }
    
    Image(
        painter = rememberDrawablePainter(icon),
        contentDescription = "App Icon",
        modifier = modifier
    )
}
```

## UI State Management

### Dashboard State:

```kotlin
data class DashboardState(
    val vpnStatus: VPNStatus = VPNStatus(),
    val stats: AppStats = AppStats(),
    val trackerControlEnabled: Boolean = true,
    val dnscryptEnabled: Boolean = false,
    val torEnabled: Boolean = false,
    val i2pEnabled: Boolean = false,
    val isLoading: Boolean = false,
    val error: String? = null
)

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val vpnServiceManager: VPNServiceManager,
    private val settingsRepository: SettingsRepository
) : ViewModel() {
    
    private val _state = MutableStateFlow(DashboardState())
    val state: StateFlow<DashboardState> = _state.asStateFlow()
    
    init {
        loadInitialState()
        observeVPNStatus()
    }
    
    fun onToggleChanged(toggle: ToggleType, enabled: Boolean) {
        viewModelScope.launch {
            when (toggle) {
                ToggleType.TRACKER_CONTROL -> {
                    settingsRepository.setTrackerControlEnabled(enabled)
                    _state.value = _state.value.copy(trackerControlEnabled = enabled)
                }
                ToggleType.DNSCRYPT -> {
                    settingsRepository.setDNSCryptEnabled(enabled)
                    _state.value = _state.value.copy(dnscryptEnabled = enabled)
                }
                ToggleType.TOR -> {
                    settingsRepository.setTorEnabled(enabled)
                    _state.value = _state.value.copy(torEnabled = enabled)
                }
                ToggleType.I2P -> {
                    settingsRepository.setI2PEnabled(enabled)
                    _state.value = _state.value.copy(i2pEnabled = enabled)
                }
            }
        }
    }
    
    private fun observeVPNStatus() {
        vpnServiceManager.observeStatus()
            .onEach { status ->
                _state.value = _state.value.copy(vpnStatus = status)
            }
            .launchIn(viewModelScope)
    }
}
```

## UI Design Principles

### 1. **Material Design 3**
- Dynamic color theming
- Consistent elevation
- Proper spacing using 8dp grid

### 2. **Accessibility**
- Proper content descriptions
- Minimum touch target sizes (48dp)
- High contrast mode support

### 3. **Performance**
- Lazy loading for large lists
- Efficient recomposition
- Proper state management

### 4. **User Experience**
- Clear visual hierarchy
- Intuitive navigation
- Immediate feedback for actions

This UI structure provides a comprehensive and user-friendly interface for managing all aspects of the Invizible Tracker Control Pro application while maintaining consistency and usability.