# Invizible Tracker Control Pro - Architecture Documentation

## High-Level Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        EXTERNAL APPLICATIONS                                 │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐      │
│  │   Browser   │  │   Social    │  │    Game     │  │    Bank     │      │
│  │    Apps     │  │    Apps     │  │    Apps     │  │    Apps     │      │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘      │
└─────────┴─────────────────┴─────────────────┴─────────────────┴─────────────┘
          │                 │                 │                 │
          ▼                 ▼                 ▼                 ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                    VPN SERVICE (Single Instance)                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                        TRAFFIC CLASSIFIER                            │   │
│  │  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐    │   │
│  │  │  Internal Subs  │  │  External Apps  │  │  System Apps    │    │   │
│  │  │  (Tor/I2P/DNS)  │  │  (User Apps)    │  │  (Optional)     │    │   │
│  │  └────────┬────────┘  └────────┬────────┘  └────────┬────────┘    │   │
│  │           │ Bypass All         │ Tracker Filter     │ Bypass/Filter │   │
│  │           ▼                    ▼                    ▼               │   │
│  │  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐    │   │
│  │  │ Internal Router │  │ Tracker Engine  │  │  Policy Engine  │    │   │
│  │  │  (Direct Pass)  │  │ (SDK + Domain)  │  │ (Per-App Rules) │    │   │
│  │  └────────┬────────┘  └────────┬────────┘  └────────┬────────┘    │   │
│  └───────────┴─────────────────────┴─────────────────────┴───────────┘   │
│              │                    │                    │                    │
│              ▼                    ▼                    ▼                    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         DNS RESOLVER ENGINE                          │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐            │   │
│  │  │  DNSCrypt    │  │    Tor       │  │     I2P      │            │   │
│  │  │   Resolver   │  │   Resolver   │  │  Resolver    │            │   │
│  │  └───────┬──────┘  └───────┬──────┘  └───────┬──────┘            │   │
│  │          │ DNS Selection   │                 │                     │   │
│  │          ▼                 ▼                 ▼                     │   │
│  │  ┌────────────────────────────────────────────────────────────────┐ │   │
│  │  │                    ROUTING ENGINE                               │ │   │
│  │  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐     │ │   │
│  │  │  │  Direct  │  │   Tor    │  │   I2P    │  │  Block   │     │ │   │
│  │  │  │  Route   │  │  Route   │  │  Route   │  │  Route   │     │ │   │
│  │  │  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘     │ │   │
│  │  └───────┴─────────────┴─────────────┴─────────────┴───────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
              │                    │                    │
              ▼                    ▼                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           NETWORK INTERFACES                                 │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │
│  │   Internet   │  │    Tor       │  │     I2P      │  │   Blocked    │   │
│  │   (Direct)   │  │   Network    │  │   Network    │  │   Traffic    │   │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Internal Subsystem Bypass Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    INTERNAL SUBSYSTEM BYPASS LOGIC                          │
│                                                                             │
│  ┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐     │
│  │   DNSCrypt      │     │      Tor        │     │       I2P       │     │
│  │    Process      │     │     Process     │     │     Process     │     │
│  │                 │     │                 │     │                 │     │
│  │ ┌─────────────┐ │     │ ┌─────────────┐ │     │ ┌─────────────┐ │     │
│  │ │  Localhost  │ │     │ │  Localhost  │ │     │ │  Localhost  │ │     │
│  │ │    5353     │ │     │ │    9050     │ │     │ │   7656-     │ │     │
│  │ │   (DNS)     │ │     │ │  (SOCKS)    │ │     │ │  (I2P)      │ │     │
│  │ └──────┬──────┘ │     │ └──────┬──────┘ │     │ └──────┬──────┘ │     │
│  └────────┼────────┘     └────────┼────────┘     └────────┼────────┘     │
│           │ Bypass All           │ Bypass All           │ Bypass All      │
│           │ No Inspection        │ No Inspection        │ No Inspection   │
│           ▼                      ▼                      ▼                 │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │                    VPN TUN INTERFACE                               │    │
│  │                    (Direct Pass-through)                           │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│           │                      │                      │                      │
│           └──────────────────────┴──────────────────────┘                      │
│                                    │                                         │
│                                    ▼                                         │
│                           ┌─────────────────┐                                │
│                           │   Raw Network   │                                │
│                           │    Interface    │                                │
│                           └─────────────────┘                                │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Key Architectural Principles

### 1. **Single VPNService Instance**
- One VPNService manages all traffic routing
- Traffic classification happens within the VPN tunnel
- No dual VPNs or VPN chaining

### 2. **Internal Subsystem Bypass**
- DNSCrypt, Tor, and I2P processes run independently
- Their traffic bypasses ALL tracker detection logic
- Direct network access for internal subsystems
- No inspection, logging, or filtering of internal traffic

### 3. **Traffic Classification**
```
Traffic Classification Logic:
1. Check source IP/port
2. If matches internal subsystem → bypass all filters
3. If external app → apply tracker detection
4. If system app → apply user-defined policy
```

### 4. **DNS Resolution Strategy**
```
DNS Resolution Rules:
- Tor apps → Tor DNS (127.0.0.1:5400)
- I2P apps → I2P DNS (127.0.0.1:7653)
- Direct apps → DNSCrypt (127.0.0.1:5353)
- Blocked apps → No DNS resolution
```

### 5. **Routing Strategy**
```
Routing Decision Matrix:
┌──────────┬──────────┬──────────┬──────────┐
│ App Type │ Tracker  │ Routing  │   DNS    │
│          │ Blocking │          │          │
├──────────┼──────────┼──────────┼──────────┤
│ Internal │   N/A    │ Direct   │ Internal │
│ Tor App  │ Optional │   Tor    │   Tor    │
│ I2P App  │ Optional │   I2P    │   I2P    │
│ Direct   │   Yes    │ Direct   │ DNSCrypt │
│ Blocked  │   Yes    │  Block   │  None    │
└──────────┴──────────┴──────────┴──────────┘
```

## Security Boundaries

### 1. **Process Isolation**
- DNSCrypt: Separate process, localhost:5353
- Tor: Separate process, localhost:9050 (SOCKS), 5400 (DNS)
- I2P: Separate process, localhost:7654-7656 range
- Main app: VPNService + UI

### 2. **Traffic Isolation**
- Internal subsystem traffic never mixed with external app traffic
- Separate routing tables for internal vs external traffic
- Firewall rules prevent cross-contamination

### 3. **Configuration Isolation**
- Internal subsystem configs isolated from user configs
- User cannot override internal routing rules
- Fail-safe defaults prevent misconfiguration

## Performance Considerations

### 1. **Efficient Packet Processing**
- Zero-copy packet handling where possible
- Asynchronous I/O for all network operations
- Connection pooling for repeated destinations

### 2. **Battery Optimization**
- Batch packet processing
- Adaptive polling intervals
- Background service optimization
- Wake-lock management

### 3. **Memory Management**
- Stream-based packet processing
- Limited buffer sizes
- Aggressive garbage collection
- Resource pooling

## Monitoring and Diagnostics

### 1. **Internal Metrics**
- Packet throughput per routing type
- DNS query resolution times
- Tracker detection statistics
- Battery usage tracking

### 2. **User-visible Metrics**
- Apps routed through each network
- Tracker blocking statistics
- Data usage per app per network type
- Connection status indicators

This architecture ensures complete privacy protection while maintaining system stability and performance. The strict separation between internal subsystems and external app traffic prevents any potential privacy leaks or circular routing issues.