# Invizible Tracker Control Pro - Per-App Policy Resolver

## Policy Resolution Architecture

### Policy Hierarchy

```
┌─────────────────────────────────────────────────────────────┐
│                    POLICY RESOLUTION HIERARCHY               │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────────┐                                        │
│  │  Global Policy  │  ← Default system-wide settings        │
│  └────────┬────────┘                                        │
│           │                                                 │
│           ▼                                                 │
│  ┌─────────────────┐                                        │
│  │ App Category    │  ← Pre-defined app categories          │
│  │ Policy          │    (Browser, Social, Banking, etc.)    │
│  └────────┬────────┘                                        │
│           │                                                 │
│           ▼                                                 │
│  ┌─────────────────┐                                        │
│  │ Individual App  │  ← Per-app user configuration          │
│  │ Policy          │                                        │
│  └────────┬────────┘                                        │
│           │                                                 │
│           ▼                                                 │
│  ┌─────────────────┐                                        │
│  │ Runtime Policy  │  ← Dynamic rules (time-based, etc.)    │
│  └─────────────────┘                                        │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## Policy Resolution Logic

```kotlin
// Main policy resolver
class PolicyResolver {
    
    // Resolve final policy for an app
    fun resolvePolicy(appInfo: AppInfo, context: PolicyContext): ResolvedPolicy {
        // Step 1: Get global policy
        val globalPolicy = getGlobalPolicy()
        
        // Step 2: Get app category policy
        val categoryPolicy = getCategoryPolicy(appInfo.category)
        
        // Step 3: Get individual app policy
        val appPolicy = getAppPolicy(appInfo.packageName)
        
        // Step 4: Apply runtime policies
        val runtimePolicy = getRuntimePolicy(appInfo, context)
        
        // Step 5: Merge policies (higher levels override lower levels)
        return mergePolicies(
            globalPolicy,
            categoryPolicy,
            appPolicy,
            runtimePolicy
        )
    }
    
    // Policy merging logic
    private fun mergePolicies(
        global: Policy,
        category: Policy,
        app: Policy,
        runtime: Policy
    ): ResolvedPolicy {
        return ResolvedPolicy(
            routing = app.routing ?: category.routing ?: global.routing ?: Route.DIRECT,
            trackerBlocking = app.trackerBlocking ?: category.trackerBlocking ?: global.trackerBlocking ?: true,
            allowedTrackers = mergeTrackerLists(
                global.allowedTrackers,
                category.allowedTrackers,
                app.allowedTrackers,
                runtime.allowedTrackers
            ),
            blockedTrackers = mergeTrackerLists(
                global.blockedTrackers,
                category.blockedTrackers,
                app.blockedTrackers,
                runtime.blockedTrackers
            ),
            firewallRules = mergeFirewallRules(
                global.firewallRules,
                category.firewallRules,
                app.firewallRules,
                runtime.firewallRules
            ),
            dnsPolicy = app.dnsPolicy ?: category.dnsPolicy ?: global.dnsPolicy ?: DNSPolicy.AUTO,
            bypassLAN = app.bypassLAN ?: category.bypassLAN ?: global.bypassLAN ?: false
        )
    }
}
```

## Global Policy Configuration

```kotlin
// Global system policy
class GlobalPolicy {
    
    val defaultPolicy = Policy(
        routing = Route.DIRECT,
        trackerBlocking = true,
        allowedTrackers = setOf(
            // Essential trackers that might break apps
            "crashlytics.com",
            "firebase.google.com"
        ),
        blockedTrackers = setOf(
            // Known malicious trackers
            "doubleclick.net",
            "googlesyndication.com",
            "facebook.com/tr"
        ),
        firewallRules = FirewallRules(
            blockedPorts = setOf(25, 135, 139, 445), // SMTP, NetBIOS, SMB
            allowedIPs = setOf("0.0.0.0/0"), // Allow all by default
            blockedIPs = setOf() // No IP blocks by default
        ),
        dnsPolicy = DNSPolicy.DNSCRYPT,
        bypassLAN = true // Bypass VPN for local network by default
    )
    
    fun getGlobalPolicy(): Policy {
        return loadFromPreferences() ?: defaultPolicy
    }
}
```

## App Category Policies

```kotlin
// Pre-defined app category policies
class CategoryPolicies {
    
    private val categoryPolicies = mapOf(
        AppCategory.BROWSER to Policy(
            routing = Route.TOR,
            trackerBlocking = true,
            allowedTrackers = setOf(
                // Allow some trackers for functionality
                "googleapis.com",
                "gstatic.com"
            ),
            blockedTrackers = setOf(
                // Block advertising trackers
                "doubleclick.net",
                "googlesyndication.com"
            ),
            dnsPolicy = DNSPolicy.TOR
        ),
        
        AppCategory.SOCIAL to Policy(
            routing = Route.TOR,
            trackerBlocking = true,
            allowedTrackers = setOf(
                // Minimal allowed trackers
                "cdninstagram.com"
            ),
            blockedTrackers = setOf(
                // Block extensive tracking
                "facebook.com",
                "fbcdn.net",
                "doubleclick.net"
            ),
            dnsPolicy = DNSPolicy.TOR
        ),
        
        AppCategory.BANKING to Policy(
            routing = Route.DIRECT,
            trackerBlocking = true,
            allowedTrackers = setOf(
                // Allow bank's own domains
                "*.bank.com",
                "*.creditunion.com"
            ),
            blockedTrackers = setOf(
                // Block all third-party trackers
                "*"
            ),
            dnsPolicy = DNSPolicy.DNSCRYPT,
            bypassLAN = false // Force VPN for banking apps
        ),
        
        AppCategory.GAMING to Policy(
            routing = Route.DIRECT,
            trackerBlocking = true,
            allowedTrackers = setOf(
                // Game analytics (optional)
                "unity3d.com",
                "unrealengine.com"
            ),
            blockedTrackers = setOf(
                // Block advertising trackers
                "doubleclick.net",
                "googlesyndication.com",
                "facebook.com/tr"
            ),
            dnsPolicy = DNSPolicy.DNSCRYPT
        ),
        
        AppCategory.EMAIL to Policy(
            routing = Route.DIRECT,
            trackerBlocking = true,
            allowedTrackers = setOf(
                // Email service domains
                "*.gmail.com",
                "*.outlook.com",
                "*.protonmail.com"
            ),
            blockedTrackers = setOf(
                // Block email tracking pixels
                "*.openxchange.net",
                "*.mailchimp.net"
            ),
            dnsPolicy = DNSPolicy.DNSCRYPT
        ),
        
        AppCategory.MESSAGING to Policy(
            routing = Route.TOR,
            trackerBlocking = true,
            allowedTrackers = setOf(),
            blockedTrackers = setOf(
                // Block all trackers in messaging apps
                "*"
            ),
            dnsPolicy = DNSPolicy.TOR
        )
    )
    
    fun getCategoryPolicy(category: AppCategory): Policy? {
        return categoryPolicies[category]
    }
}
```

## Individual App Policy Management

```kotlin
// Per-app policy management
class AppPolicyManager {
    
    // Set custom policy for specific app
    fun setAppPolicy(packageName: String, policy: Policy) {
        // Validate policy doesn't conflict with internal subsystems
        if (isInternalSubsystem(packageName)) {
            throw SecurityException("Cannot modify policy for internal subsystems")
        }
        
        // Store in database
        appPolicyDatabase.savePolicy(packageName, policy)
        
        // Notify VPN service of policy change
        notifyVPNService(packageName, policy)
    }
    
    // Get app policy
    fun getAppPolicy(packageName: String): Policy? {
        return appPolicyDatabase.getPolicy(packageName)
    }
    
    // Reset app to category default
    fun resetAppPolicy(packageName: String) {
        val appInfo = getAppInfo(packageName)
        val categoryPolicy = categoryPolicies.getPolicy(appInfo.category)
        
        if (categoryPolicy != null) {
            setAppPolicy(packageName, categoryPolicy)
        } else {
            // Remove custom policy to use global default
            appPolicyDatabase.removePolicy(packageName)
        }
    }
    
    // Validate policy conflicts
    fun validatePolicy(policy: Policy): ValidationResult {
        val errors = mutableListOf<String>()
        
        // Check for DNS leaks
        if (policy.routing == Route.TOR && policy.dnsPolicy != DNSPolicy.TOR) {
            errors.add("Tor routing requires Tor DNS to prevent leaks")
        }
        
        if (policy.routing == Route.I2P && policy.dnsPolicy != DNSPolicy.I2P) {
            errors.add("I2P routing requires I2P DNS to prevent leaks")
        }
        
        // Check for conflicting tracker rules
        val conflicts = policy.allowedTrackers.intersect(policy.blockedTrackers)
        if (conflicts.isNotEmpty()) {
            errors.add("Conflicting tracker rules: $conflicts")
        }
        
        return ValidationResult(
            isValid = errors.isEmpty(),
            errors = errors
        )
    }
}
```

## Runtime Policy Rules

```kotlin
// Dynamic runtime policies
class RuntimePolicyManager {
    
    // Time-based policies
    fun getTimeBasedPolicy(appInfo: AppInfo, context: PolicyContext): Policy? {
        val currentTime = System.currentTimeMillis()
        val hour = getCurrentHour()
        
        return when {
            // Work hours - stricter policies
            hour in 9..17 -> Policy(
                routing = Route.TOR,
                trackerBlocking = true,
                allowedTrackers = setOf(),
                blockedTrackers = setOf("*")
            )
            
            // Personal time - relaxed policies
            else -> Policy(
                routing = appInfo.routingPolicy.route,
                trackerBlocking = true,
                allowedTrackers = setOf("googleapis.com"),
                blockedTrackers = setOf("doubleclick.net")
            )
        }
    }
    
    // Location-based policies
    fun getLocationBasedPolicy(appInfo: AppInfo, context: PolicyContext): Policy? {
        return when (context.location) {
            Location.HOME -> Policy(
                bypassLAN = true,
                routing = Route.DIRECT
            )
            
            Location.WORK -> Policy(
                bypassLAN = false,
                routing = Route.TOR
            )
            
            Location.PUBLIC -> Policy(
                bypassLAN = false,
                routing = Route.TOR,
                trackerBlocking = true,
                blockedTrackers = setOf("*")
            )
            
            else -> null
        }
    }
    
    // Network-based policies
    fun getNetworkBasedPolicy(appInfo: AppInfo, context: PolicyContext): Policy? {
        return when (context.networkType) {
            NetworkType.WIFI_TRUSTED -> Policy(
                routing = Route.DIRECT,
                bypassLAN = true
            )
            
            NetworkType.WIFI_UNTRUSTED -> Policy(
                routing = Route.TOR,
                bypassLAN = false
            )
            
            NetworkType.MOBILE -> Policy(
                routing = Route.TOR,
                bypassLAN = false,
                // Block high-bandwidth trackers on mobile
                blockedTrackers = setOf("doubleclick.net", "youtube.com")
            )
            
            else -> null
        }
    }
}
```

## Policy Conflict Resolution

```kotlin
// Policy conflict resolver
class PolicyConflictResolver {
    
    fun resolveConflicts(policies: List<Policy>): Policy {
        // Most specific policy wins
        return policies.reduce { merged, current ->
            Policy(
                routing = current.routing ?: merged.routing,
                trackerBlocking = current.trackerBlocking ?: merged.trackerBlocking,
                allowedTrackers = mergeTrackerLists(
                    merged.allowedTrackers,
                    current.allowedTrackers
                ),
                blockedTrackers = mergeTrackerLists(
                    merged.blockedTrackers,
                    current.blockedTrackers
                ),
                firewallRules = mergeFirewallRules(
                    merged.firewallRules,
                    current.firewallRules
                ),
                dnsPolicy = current.dnsPolicy ?: merged.dnsPolicy,
                bypassLAN = current.bypassLAN ?: merged.bypassLAN
            )
        }
    }
    
    private fun mergeTrackerLists(list1: Set<String>, list2: Set<String>): Set<String> {
        // Combine lists, removing duplicates
        return (list1 + list2).toSet()
    }
    
    private fun mergeFirewallRules(rules1: FirewallRules, rules2: FirewallRules): FirewallRules {
        return FirewallRules(
            blockedPorts = (rules1.blockedPorts + rules2.blockedPorts).toSet(),
            allowedIPs = (rules1.allowedIPs + rules2.allowedIPs).toSet(),
            blockedIPs = (rules1.blockedIPs + rules2.blockedIPs).toSet()
        )
    }
}
```

## Policy Enforcement

```kotlin
// Policy enforcement engine
class PolicyEnforcementEngine {
    
    private val policyResolver = PolicyResolver()
    private val cache = LruCache<String, ResolvedPolicy>(1000)
    
    // Get cached or resolved policy for app
    fun getPolicy(appInfo: AppInfo, context: PolicyContext): ResolvedPolicy {
        val cacheKey = "${appInfo.packageName}:${context.hashCode()}"
        
        return cache[cacheKey] ?: run {
            val resolved = policyResolver.resolvePolicy(appInfo, context)
            cache.put(cacheKey, resolved)
            resolved
        }
    }
    
    // Apply policy to packet
    fun applyPolicy(packet: Packet, appInfo: AppInfo, policy: ResolvedPolicy): PolicyAction {
        return when {
            // Check if app is blocked
            policy.isBlocked -> PolicyAction.BLOCK
            
            // Check tracker blocking
            packet.isTrackerTraffic() && policy.trackerBlocking -> {
                if (isAllowedTracker(packet, policy)) {
                    PolicyAction.ALLOW
                } else {
                    PolicyAction.BLOCK_TRACKER
                }
            }
            
            // Check firewall rules
            violatesFirewallRules(packet, policy) -> PolicyAction.BLOCK_FIREWALL
            
            // Apply routing policy
            else -> PolicyAction.ROUTE(policy.routing)
        }
    }
    
    // Clear policy cache
    fun clearCache() {
        cache.evictAll()
    }
    
    // Update policy for app
    fun updatePolicy(packageName: String, policy: Policy) {
        // Clear cache entries for this app
        cache.snapshot().keys.forEach { key ->
            if (key.startsWith(packageName)) {
                cache.remove(key)
            }
        }
    }
}

// Policy action types
sealed class PolicyAction {
    object ALLOW : PolicyAction()
    object BLOCK : PolicyAction()
    object BLOCK_TRACKER : PolicyAction()
    object BLOCK_FIREWALL : PolicyAction()
    data class ROUTE(val route: Route) : PolicyAction()
}
```

## Policy Import/Export

```kotlin
// Policy backup and restore
class PolicyBackupManager {
    
    // Export all policies
    fun exportPolicies(): PolicyBackup {
        return PolicyBackup(
            version = 1,
            timestamp = System.currentTimeMillis(),
            globalPolicy = globalPolicyManager.getGlobalPolicy(),
            appPolicies = appPolicyManager.getAllAppPolicies(),
            categoryPolicies = categoryPolicies.getAllPolicies()
        )
    }
    
    // Import policies
    fun importPolicies(backup: PolicyBackup): ImportResult {
        return try {
            // Validate backup
            if (!isValidBackup(backup)) {
                return ImportResult.Failure("Invalid backup file")
            }
            
            // Import with conflict resolution
            backup.globalPolicy?.let {
                globalPolicyManager.setGlobalPolicy(it)
            }
            
            backup.appPolicies.forEach { (packageName, policy) ->
                appPolicyManager.setAppPolicy(packageName, policy)
            }
            
            ImportResult.Success
        } catch (e: Exception) {
            ImportResult.Failure(e.message ?: "Import failed")
        }
    }
}
```

## Policy Analytics

```kotlin
// Policy usage analytics
class PolicyAnalytics {
    
    // Track policy effectiveness
    fun trackPolicyEffectiveness(appInfo: AppInfo, policy: ResolvedPolicy) {
        val metrics = PolicyMetrics(
            packageName = appInfo.packageName,
            routing = policy.routing,
            trackerBlocking = policy.trackerBlocking,
            blockedTrackersCount = policy.blockedTrackers.size,
            allowedTrackersCount = policy.allowedTrackers.size
        )
        
        analyticsDatabase.recordMetrics(metrics)
    }
    
    // Generate policy recommendations
    fun generateRecommendations(appInfo: AppInfo): List<PolicyRecommendation> {
        val recommendations = mutableListOf<PolicyRecommendation>()
        
        // Analyze app behavior
        val appMetrics = analyticsDatabase.getAppMetrics(appInfo.packageName)
        
        // Recommend stricter policies for high-tracker apps
        if (appMetrics.trackerConnections > 50) {
            recommendations.add(
                PolicyRecommendation(
                    type = RecommendationType.INCREASE_BLOCKING,
                    message = "This app connects to many trackers. Consider stricter blocking.",
                    suggestedPolicy = Policy(
                        routing = Route.TOR,
                        trackerBlocking = true,
                        blockedTrackers = setOf("*")
                    )
                )
            )
        }
        
        return recommendations
    }
}
```

This comprehensive policy resolver system ensures that each app gets the appropriate privacy protection while maintaining usability and preventing conflicts between different policy layers.